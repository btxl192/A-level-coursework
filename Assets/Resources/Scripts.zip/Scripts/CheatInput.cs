﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CheatInput : MonoBehaviour {

    private string UserInput;
    private GameObject Player;

	void Start ()
    {
        Player = GameObject.FindGameObjectWithTag("Player");
        this.gameObject.GetComponent<RectTransform>().sizeDelta = new Vector2(Screen.width, this.gameObject.GetComponent<RectTransform>().sizeDelta.y);
	}
	
	void Update ()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
            UserInput = this.GetComponent<InputField>().text;
            string[] UserInputParts = UserInput.Split(" ".ToCharArray()[0]);

            if (UserInputParts[0] == "/addskillpoints")
            {
                try
                {
                    Player.GetComponent<PlayerStats>().ChangeSkillPoints(int.Parse(UserInputParts[1]));
                    IngameLog.Log("Added " + UserInputParts[1] + " skill points", Color.white);
                }
                catch
                {
                    IngameLog.Log("Please input a proper amount of skill points!", Color.red);
                }
            }
            else if (UserInputParts[0] == "/addcurrency")
            {
                try
                {
                    Player.GetComponent<PlayerInventory>().Gold += int.Parse(UserInputParts[1]);
                    IngameLog.Log("Added " + UserInputParts[1] + " gold", Color.white);
                }
                catch
                {
                    TempPopup.Show("Please input a proper amount of gold!", Color.red);
                }
            }
            else if (UserInputParts[0] == "/changehealth")
            {
                try
                {
                    Player.GetComponent<PlayerStats>().HP.ChangeHealth(int.Parse(UserInputParts[1]));
                    IngameLog.Log("Changed health by " + UserInputParts[1] + " points", Color.white);
                }
                catch
                {
                    IngameLog.Log("Please input an integer!", Color.red);
                }
            }
            else
            {
                IngameLog.Log("No such command as '" + UserInputParts[0] + "'", Color.red);
            }
        }
	}
}
