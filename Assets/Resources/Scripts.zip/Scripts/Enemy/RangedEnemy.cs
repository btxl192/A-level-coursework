﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;
using System;

public class RangedEnemy : GenericEnemy {

	public GameObject Projectile; 
	protected float atttimer;
    [SerializeField]
    protected float attspeed;

	protected override void Start () 
	{
		base.Start();
		atttimer = 0f;
	}
	
	protected override void AdditionalBehaviour () 
	{
        atttimer += Time.deltaTime;
		if(Physics.Linecast(transform.position,Player.transform.position))
		{
			if(Vector3.Distance(Player.transform.position,this.gameObject.transform.position) <= 2.5)
			{
				Vector3 look = Player.transform.position - transform.position;
				look.y = 0;
				transform.rotation = Quaternion.LookRotation((look).normalized);
				this.gameObject.GetComponent<NavMeshAgent> ().SetDestination (transform.position);
				if(atttimer>+attspeed)
				{
					atttimer = 0f;
					Projectile.GetComponent<GenericProjectile>().Shoot(Projectile, this.gameObject, Player, CalcDamage(Projectile.GetComponent<GenericProjectile>().damage, Level));
				}
			}
			else
			{
				this.gameObject.GetComponent<NavMeshAgent> ().SetDestination (Player.transform.position);
			}
		} 
	}

    public int CalcDamage(int Damage, int Level)
    {
        return (int)(Damage * (1 + ((Level - 1) * 0.2f)));
    }
}
