﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;
using System;

public class GenericEnemy : MonoBehaviour {

	public int maxhealth;

    [SerializeField]
    protected int _health;
    public int health
    {
        get
        {
            return _health;
        }
    }

    [SerializeField]
	protected int _damage;
	public int damage
	{
		get {return _damage;}
	}

    [SerializeField]
	protected int _exp;
	public int exp
	{
		get { return _exp; }
	}

    [SerializeField]
	protected int _Level;
	public int Level
	{
		get { return _Level; }
	}

    [SerializeField]
	protected int _DropChance;
	public int DropChance
	{
		get {return _DropChance;}
	}

	public delegate void intevent(int e);
	public static event intevent giveexp;
    public static event intevent SendPos;

	protected Slider _healthbar;
	protected Canvas mainui;
	protected GameObject Player;
	protected List<Statuses.StatusType> StatusEffects = new List<Statuses.StatusType> ();
	protected bool isdead;
	protected Material thismaterial;
    protected int EnemyID;
    protected List<EnemyItemDrop> DropTable = new List<EnemyItemDrop>();
    protected bool OnGround;

	protected virtual void Start () 
	{
		isdead = false;
		_health = maxhealth;
		mainui = GameObject.FindGameObjectWithTag ("MainUI").GetComponent<Canvas>();
		GameObject tempbar = Resources.Load (FileDir.EnemyHealthBar) as GameObject;
		_healthbar = Instantiate (tempbar.GetComponent<Slider>(), mainui.transform);
        Player = GameObject.FindGameObjectWithTag ("Player");
		this.gameObject.tag = "Enemy";
		Enemies.AddEnemy(this.gameObject);
        DropTable = new List<EnemyItemDrop>()
        {
            new EnemyItemDrop(Resources.Load(FileDir.RandomWeaponPickup) as GameObject,2),
            //new EnemyItemDrop(Resources.Load(FileDir.LesserHealingPotion) as GameObject,1),
            new EnemyItemDrop(Resources.Load(FileDir.RandomArmourPickup) as GameObject,1),
        };
        SetDropTable();
        thismaterial = this.gameObject.GetComponent<Renderer>().material;
        EnemyID = Enemies.GetEnemies().IndexOf(this.gameObject);
	}

    void SetDropTable()
    {
        int totalskew = 0;
        foreach (EnemyItemDrop i in DropTable)
        {
            for (int a = 0; a < i.Skew; a++)
            {
                totalskew += 1;
            }
            i.SumSkew = totalskew;
        }
    }

    protected void Update()
    {
        UpdateHealthBar();
        SendPos(EnemyID);
        if (!Pause.Paused)
		{
            if (OnGround)
            {             
                this.gameObject.GetComponent<NavMeshAgent>().SetDestination(Player.transform.position);
            }
            AdditionalBehaviour ();
			if (_health <= 0)
			{
				if (!isdead) 
				{
					isdead = true;
					dead();
					this.gameObject.AddComponent<FadeOut> ().FadePeriod = 0.5f;
				} 

			}
		} 
    }

	protected virtual void AdditionalBehaviour()
	{
	}

	public void TakeDamage(int d)
	{
		_health -= d;
	}

	protected void UpdateHealthBar()
	{
		if (!Pause.Paused && (GenericMenu.OpenMenu == null || GenericMenu2.OpenMenu == null))
		{
			_healthbar.gameObject.SetActive (true);
            _healthbar.transform.position = Camera.main.WorldToScreenPoint(this.transform.position) + new Vector3(0f,20f,0f);
            _healthbar.value = _health; 
            _healthbar.gameObject.GetComponent<EnemyHealthBar>().healthnum.text = health + "/" + maxhealth;
            _healthbar.gameObject.GetComponent<EnemyHealthBar>().levelnum.text = "Lv. " + Level;
        } 
		else
		{
			_healthbar.gameObject.SetActive (false);
        }
	}

	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.CompareTag("Projectile") && !other.GetComponent<GenericWeapon>().WhiteListed(this.gameObject)) //if the enemy collides with an object with the tag "Projectile", the enemy takes _damage
		{
			GenericWeapon weapon = other.gameObject.GetComponent<GenericWeapon> ();
			_health -= weapon.damage;
		}

	}

	protected void dead()
	{
		Enemies.RemoveEnemy (this.gameObject); //removes the object from the list of enemies
		Destroy (GetComponent<Rigidbody>()); //removes the rigidbody of the object. This means physics no longer applies to the game object
        this.GetComponent<BoxCollider>().enabled = false; //This prevents the player from making any further collision with the enemy
		_healthbar.transform.SetParent (this.transform);
		giveexp (_exp);
		int dropnum = UnityEngine.Random.Range (1, 100);
		if (dropnum >= (100 - DropChance))
		{
            int dropindex = GetDropIndex();
            if (DropTable[dropindex].Item.GetComponent<HealingItem>() != null)
            {
                DropTable[dropindex].Item.GetComponent<HealingItem>().ChangeAmount(UnityEngine.Random.Range(1,4));
            }
            this.gameObject.GetComponent<ItemDrop>().DropItem(DropTable[dropindex].Item, 60f, 0f);
		}
	}

    void OnCollisionEnter(Collision other)
	{
        if (other.gameObject.CompareTag("Player")) //checks for a collision with the player
		{
			other.gameObject.GetComponent<PlayerBehaviour>().takedamage(damage);
			if (StatusEffects.Count > 0)
			{
                foreach (Statuses.StatusType s in StatusEffects)
                {
                    other.gameObject.GetComponent<Statuses>().ApplyStatus(s, this.gameObject);
                }
			}

		}
        if (other.gameObject.CompareTag("Ground"))
        {
            this.gameObject.GetComponent<NavMeshAgent>().enabled = true;
            OnGround = true;
        }
	}

    protected int GetDropIndex()
    {
        //UnityEngine.Random.InitState(System.DateTime.Now.Millisecond);
        int skewnum = UnityEngine.Random.Range(1, DropTable[DropTable.Count-1].SumSkew + 1);
        for (int a = 0; a < DropTable.Count; a++)
        {
            if (skewnum <= DropTable[a].SumSkew)
            {
                return a;
            }
        }
        return -1;
    }

    protected void DropRandomItem()
    {
        int dropindex = GetDropIndex();
        if (DropTable[dropindex].Item.GetComponent<HealingItem>() != null)
        {
            DropTable[dropindex].Item.GetComponent<HealingItem>().ChangeAmount(UnityEngine.Random.Range(1, 4));
        }
        this.gameObject.GetComponent<ItemDrop>().DropItem(DropTable[GetDropIndex()].Item, 60f, 0f);
    }

    public void SetLevel(int i)
    {
        _Level = i;
    }
}
