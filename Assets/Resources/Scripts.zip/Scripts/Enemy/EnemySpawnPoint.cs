﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawnPoint : MonoBehaviour 
{
	public GameObject EnemyToSpawn;
	public float SpawnPeriod;
    public int EnemyLevel;

	private float TimeSinceLastSpawn;

	void Update()
	{
		if (TimeSinceLastSpawn > SpawnPeriod) 
		{
			if (Enemies.GetEnemies ().Count < Enemies.MaxEnemies) 
			{
				try
				{
					Instantiate (EnemyToSpawn, this.transform.position, Quaternion.identity).GetComponent<GenericEnemy>().SetLevel(EnemyLevel);
				}
				catch 
				{
					print ("No enemy assigned");
				}
			}
			TimeSinceLastSpawn = 0f;
		} 
		else 
		{
			TimeSinceLastSpawn += Time.deltaTime;
		}
	}
}
