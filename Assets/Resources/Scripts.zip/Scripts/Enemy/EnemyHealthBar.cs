﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyHealthBar : MonoBehaviour {

    public Text healthnum;
    public Text levelnum;

    public void SetValues(int healthnumvalue, int levelnumvalue)
    {
        healthnum.text = healthnumvalue.ToString();
        levelnum.text = levelnumvalue.ToString();
    }
}
