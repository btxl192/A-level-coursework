﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestDrop : GenericEnemy
{
    private int amounttodrop = 50;
	private Dictionary<GameObject, int> test = new Dictionary<GameObject, int>();

    protected override void Start()
    {
        base.Start();
        _damage = 0;
        for (int a = 0; a < amounttodrop; a++)
        {
            int dropindex = GetDropIndex();
            this.gameObject.GetComponent<ItemDrop>().DropItem(DropTable[dropindex].Item, 5f, 0f);
            try
            {
				test.Add(DropTable[dropindex].Item, 1);
            }
            catch
            {
				test[DropTable[dropindex].Item] += 1;
            }
        }
		foreach (GameObject key in test.Keys) 
		{
			print (key + ": " + test [key]);
		}
    }
}
