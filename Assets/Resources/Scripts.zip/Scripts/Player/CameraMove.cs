﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CameraMove : MonoBehaviour {

	private GameObject player;
	Vector3 offset;

	void Start () 
	{
		player = GameObject.FindGameObjectWithTag("Player");
		offset = transform.position - player.transform.position;
	}

	void Update () 
	{
		Vector3 pos = player.transform.position + offset; //every frame, the position of the camera is changed to maintain the same offset to the player
		pos.y = 2f; //the camera is always at a height of 2
		transform.position = pos;

	}
}
