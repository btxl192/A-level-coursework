﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LockingOn : MonoBehaviour {
	
	public Image lockedontarget;

	private Canvas mainui;
	private Image _lockedontarget;

	private PlayerBehaviour Player;

	void Start () 
	{
		Player = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerBehaviour>();
		mainui = GameObject.FindGameObjectWithTag ("MainUI").GetComponent<Canvas>();
	}

	void Update () 
	{
        if (!Pause.Paused)
        {
            if (Player.lockedon != null)
            {
                _lockedontarget.transform.SetParent(mainui.transform);
                _lockedontarget.transform.position = Camera.main.WorldToScreenPoint(Player.lockedon.transform.position);
            }

            if (KeyBindings.KeyPressed("LockOn") && Player.lockedon != null)
            {
                Player.lockedon = null;
                Destroy(_lockedontarget);
            }

            if (Player.lockedon == null)
            {
                Destroy(_lockedontarget);
            }

            if (KeyBindings.KeyPressed("LockOn") && Player.lockedon == null)
            {
                int ClosestIndex = GetIndexOfClosestEnemyToMousePoint();
                if (ClosestIndex != -1)
                {
                    Player.lockedon = Enemies.GetEnemies()[ClosestIndex];
                    _lockedontarget = Instantiate(lockedontarget);
                }
            }
        }
	}

    public static int GetIndexOfClosestEnemyToMousePoint()
    {
        Ray mousetoground = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit rayhit;
        int index = -1;
        int count = 0;
        if (Physics.Raycast(mousetoground, out rayhit, 100f))
        {
            foreach (GameObject e in Enemies.GetEnemies())
            {
                float lowest = -1f;
                Transform loc = e.transform;
                float distance = Vector3.Distance(loc.position, rayhit.point);
                if ((lowest == -1f || distance < lowest) && distance < 0.7f)
                {
                    lowest = distance;
                    index = count;
                }
                count += 1;
            }
        }
        return index;
    }
}