﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillManager : MonoBehaviour {

	public static readonly Dictionary<int, Skill> SkillDict = new Dictionary<int, Skill> ()
	{
		{0, new Toxic(0, 10)},
		{1, new Blizzard(0, 10)},
		{2, new Explosion(0, 10)},
		{3, new Smog(0, 10)},
        {4, new ChainLightning(0,10) }
	};

	protected static Dictionary<int, Skill> PlayerSkills = new Dictionary<int, Skill> ();
    public static Dictionary<int, Skill> Skills
    {
        get { return PlayerSkills;  }
    }

    public delegate void BlankEvent();
	public static event BlankEvent UpdateButtonText;
	public static event BlankEvent Ready;

	public delegate void AddSkillButtonsEvent(List<Skill> Skills);
	public static event AddSkillButtonsEvent RunAddSkillButton;

	protected static GameObject Player;
	protected static SkillCore SkillCoreEquipped;

	protected virtual void Start()
	{
		Player = GameObject.FindGameObjectWithTag("Player");
		SkillButton.IncreaseSkill += IncreaseSkill;
		SkillsetDropdown.UpdateSkills += UpdateSkills;
        for (int a = 0; a < SkillDict.Count; a++)
        {
            PlayerSkills.Add(a, SkillDict[a].Clone());
        }
        foreach (Skill s in PlayerSkills.Values)
        {
            if (s.IsActiveSkill)
            {
                ((ActiveSkill)s).Setup();
            }
        }
        Ready();
        RefreshSkillcore(null);
        PlayerEquipment.ChangedSkillCore += RefreshSkillcore;
	}

	public void RefreshSkillcore(GameObject i)
	{
        try
        {
            SkillCoreEquipped = Player.GetComponent<PlayerEquipment>().SkillCore.GetComponent<SkillCore>();
            foreach (Skill s in SkillCoreEquipped.Skills)
            {
                foreach (Skill s2 in PlayerSkills.Values)
                {
                    if (s.GetType() == s2.GetType())
                    {
                        s2.SetOverLevel(s.Level);
                    }
                }
            }
            RunUpdateButtonText();
        }
        catch (UnassignedReferenceException)
        { print("ERROR in SkillManager: couldn't get skill core. no skill core equipped?"); }
		catch { print("ERROR: problem with skill core");}
	}

	public virtual void IncreaseSkill(bool active, int SkillID, int Levels)
	{
		Increment(SkillID, Levels);
	}

	public void RunUpdateButtonText()
	{
		try
		{
			UpdateButtonText();
		}
		catch
		{
			print("ERROR: couldn't update skill text. maybe no skill buttons?");
		}
	}

    public void UpdateSkills(Skill.SkillSets SkillSet)
    {
		List<Skill> temp = new List<Skill>();
		foreach(Skill s in PlayerSkills.Values)
		{
			if(s.SkillSet == SkillSet)
			{
				temp.Add(s);
			}
		}
		RunAddSkillButton(temp);
		RunUpdateButtonText();
    }

	public void Increment(int SkillID, int Levels)
	{
		PlayerSkills[SkillID].IncreaseLevel(Levels);
		UpdateButtonText();
	}

	public static int SkillIndex(List<Skill> sk, string SkillName)
	{
		int index = 0;
		foreach (Skill item in sk)
		{
			if (item.SkillName == SkillName)
			{
				return index;
			}
			index += 1;
		}
		return -1;
	}

	public static int GetSkillDictKey(Skill Skill)
	{
		for(int a = 0; a<(SkillDict.Count); a++)
		{
			if(Skill.SkillName == SkillDict[a].SkillName)
			{
				return a;
			}
		}
		return -1;
	}
}
