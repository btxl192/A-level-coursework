﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Toxic : Skill {

	public override SkillSets SkillSet {get {return SkillSets.Assassin; }}

    public override bool IsActiveSkill
    {
        get
        {
            return false;
        }
    }

    public override string SkillName { get { return "Toxic"; } }

    public Toxic(int Lv, int MaxLv) : base(Lv,MaxLv)
	{
	}

	public override string GetDescLevel(int lvl)
	{
		if(lvl==1)
		{
			return "Improves poison damage by " + lvl + " level";
		}
		return "Improves poison damage by " + lvl + " levels";
	}

    protected override Skill MakeClone()
    {
        return new Toxic(this.CurrentLevel, this.MaxLevel);
    }
}
