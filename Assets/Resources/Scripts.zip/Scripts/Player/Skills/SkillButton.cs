﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class SkillButton : MonoBehaviour, IPointerClickHandler {

	public int SkillID;
	public bool isActiveSkill;
	public delegate void IncreaseSkillEvent(bool active, int id, int i);
	public static event IncreaseSkillEvent IncreaseSkill;
	
	private GameObject Player;

	void Awake () 
	{
		Player = GameObject.FindGameObjectWithTag("Player");
		this.GetComponent<RectTransform>().sizeDelta = new Vector2 (Screen.width*0.15f, Screen.height*0.1f);
		if (isActiveSkill) 
		{
			this.GetComponent<HoverText> ().ParentTag = "ActiveBG";
		} 
		else 
		{
			this.GetComponent<HoverText> ().ParentTag = "PassiveBG";
		}
		SkillManager.UpdateButtonText+=UpdateText;
		PlayerStats.CheckStats += UpdateText;
		UpdateText();
	}

    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.button == PointerEventData.InputButton.Left)
        {
            IncrSkill();
        }
        else if (eventData.button == PointerEventData.InputButton.Right && isActiveSkill)
        {
            CheckForKey();
        }
    }

    void IncrSkill()
	{
		if(Player.GetComponent<PlayerStats>().skillpoints > 0)
		{
            if (SkillManager.Skills[SkillID].CurrentLevel < SkillManager.Skills[SkillID].MaxLevel)
            {
                IncreaseSkill(isActiveSkill, SkillID, 1);
                Player.GetComponent<PlayerStats>().ChangeSkillPoints(-1);
            }
		}
		else
		{
			IngameLog.Log("Not enough skillpoints!", Color.red);
		}
        UpdateText();
	}

	void UpdateText()
	{
		UpdateActiveSkill();
		Skill Skill;
		Skill = SkillManager.Skills[SkillID];
		this.GetComponentInChildren<Text>().text = Skill.SkillName;
		this.GetComponentInChildren<Text>().text += "\n" + Skill.SkillDesc;
        this.gameObject.GetComponentInChildren<Text>().text = Skill.SkillName + " (" + Skill.CurrentLevel;
        if (Skill.OverLevel > 0)
        {
            this.gameObject.GetComponentInChildren<Text>().text += "+" + Skill.OverLevel;
        }
        this.gameObject.GetComponentInChildren<Text>().text += "/" + Skill.MaxLevel + ")";

        try
		{
			this.GetComponentInChildren<HoverText> ().Text = ("[Level " + Skill.Level + "]");
            if (Skill.IsActiveSkill)
            {
                this.GetComponentInChildren<HoverText>().Text += " (MP cost: " + ((ActiveSkill)Skill).ManaCost + ")" + " [" + KeyBindings.KeyBinds[Skill.SkillName] + "]";
            }
            this.GetComponentInChildren<HoverText>().Text += "\n" + Skill.GetDescLevel(Skill.Level);
            if (Skill.Level < Skill.MaxLevel)
            {
                this.GetComponentInChildren<HoverText>().Text += ("\n\nNext level: [Level " + (Skill.Level+1) + "]");
                if (Skill.IsActiveSkill)
                {
                    this.GetComponentInChildren<HoverText>().Text += " (MP cost: " + ((ActiveSkill)Skill).ManaCost + ")" + " [" + KeyBindings.KeyBinds[Skill.SkillName] + "]";
                }
                this.GetComponentInChildren<HoverText>().Text += "\n" + Skill.GetDescLevel(Skill.Level + 1);
            }
            this.GetComponentInChildren<HoverText>().ChangeText(this.GetComponentInChildren<HoverText>().Text);
        }
        catch 
		{
		}
    }

	void UpdateActiveSkill()
	{
		isActiveSkill = SkillManager.SkillDict[SkillID].IsActiveSkill;
	}

	public void Destroy()
	{
		SkillManager.UpdateButtonText -= UpdateText;
		PlayerStats.CheckStats -= UpdateText;
		Destroy(this.gameObject);
	}

    void CheckForKey()
    {
        if (SkillManager.Skills[SkillID].Level > 0)
        {
			GetKeyPress.InstantiateKeyPress(GetKeyPress.Receivers.SkillButton);
			GetKeyPress.SendKey += GetKey;
        }
        else
        {
            TempPopup.Show("Cannot assign keybind to a skill that is level 0!", Color.red);
        }
    }

    void GetKey(string key, GetKeyPress.Receivers r)
    {
        GetKeyPress.Receivers thisReceiver = GetKeyPress.Receivers.SkillButton;
        GetKeyPress.SendKey -= GetKey;
        if (r == thisReceiver)
        {
            if (!KeyBindings.IsKeyBound(key))
            {
                KeyBindings.KeyBinds[SkillManager.SkillDict[SkillID].SkillName] = key;               
                UpdateText();
                ActiveSkillManager.UpdateKeys();
            }
            else
            {
                TempPopup.Show(key + " Key is already bound!", Color.red);
            }
        }
    }
}
