﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SkillsetDropdown : MonoBehaviour {

	[SerializeField]
	private Dropdown thisdropdown;
	public Skill.SkillSets SkillSet {get; private set; }

	public delegate void UpdateSkillsEvent(Skill.SkillSets SkillSet);
	public static event UpdateSkillsEvent UpdateSkills;

	void Awake () 
	{
		thisdropdown = this.gameObject.GetComponent<Dropdown>();
		SkillManager.Ready += GetSkillSet;
        Inventory.OnOpen += UpdatePlayerSkills;
        Inventory.OnOpen += Enable;
        Inventory.OnClose += Disable;
	}

	public void GetSkillSet()
	{
		switch(thisdropdown.value)
		{
			case 0:
				SkillSet = Skill.SkillSets.Assassin;
				break;
			case 1:
				SkillSet = Skill.SkillSets.Infrigidare;
				break;
			case 2:
				SkillSet = Skill.SkillSets.Pyromaniac;
				break;
			default:
				break;
		}
		UpdateSkills(SkillSet);
	}

    void UpdatePlayerSkills()
    {
        UpdateSkills(SkillSet);
    }

    void Enable()
    {
        for (int a = 2; a < this.GetComponentsInChildren<RectTransform>(true).Length; a++)
        {
            this.GetComponentsInChildren<RectTransform>(true)[a].gameObject.SetActive(true);
        }
    }

    void Disable()
    {
        for (int a = 2; a < this.GetComponentsInChildren<RectTransform>(true).Length; a++)
        {
            this.GetComponentsInChildren<RectTransform>(true)[a].gameObject.SetActive(false);
        }
    }
}
