﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class ActiveSkill : Skill {

    public abstract bool HoldKey { get;}
    public abstract int ManaCost { get; }
    protected GameObject Player { get { return GameObject.FindGameObjectWithTag("Player"); } }
    protected PlayerStats PStats { get { return Player.GetComponent<PlayerStats>(); } }

    public ActiveSkill(int Lv, int MaxLv) : base(Lv, MaxLv)
    {
    }

    public void Activate()
    {       
        if (Level > 0 && !Pause.Paused)
        {
            if ((Player.GetComponent<PlayerStats>().MP.mana - ManaCost) >= 0)
            {
                UseSkill();
                Player.GetComponent<PlayerStats>().MP.ChangeMana(-ManaCost);
            }
            else
            {
                TempPopup.Show("Not enough mana to cast skill!", Color.red);
            }
        }
    }

    public override void UpdateSkillDesc()
    {
        base.UpdateSkillDesc();
    }

    public abstract void UseSkill();

    public virtual void Setup() { }
}
