﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Skill {

	public enum SkillSets {Assassin, Pyromaniac, Infrigidare};
	
	public abstract SkillSets SkillSet{get;}
	public abstract bool IsActiveSkill{get;}
	public abstract string SkillName{get;}
    public int Level
    {
        get { return CurrentLevel + OverLevel; }
    }
	public int CurrentLevel{get; protected set; }
    public int OverLevel { get; protected set; }
	public int MaxLevel{get; protected set; }
	public string SkillDesc{get; protected set; }

	public Skill(int Lv, int MaxLv)
	{
		PlayerStats.CheckStats += UpdateSkillDesc;
		PlayerInventory.ChangedEQ += UpdateSkillDesc;
		SkillManager.Ready += UpdateSkillDesc;
        CurrentLevel = Lv;
		MaxLevel = MaxLv;
	}

	public void IncreaseLevel(int i)
	{
		for(int a = 0; a < i; a++)
		{
			if (CurrentLevel < MaxLevel)
			{
                CurrentLevel += 1;
				try
				{
					UpdateSkillDesc();
				}
				catch
				{
					MonoBehaviour.print("problem with upgrading skill");
				}
			}
		}
	}

    public void SetOverLevel(int i)
    {
        OverLevel = i;
    }

	public virtual void UpdateSkillDesc()
	{
		try
		{
			if(CurrentLevel == 0)
			{
				SkillDesc = "\n[Level 1]\n" + GetDescLevel(1);
			}
			else
			{
				SkillDesc = "\n[Level "+ CurrentLevel + "]\n" + GetDescLevel(CurrentLevel);
				if(CurrentLevel < MaxLevel)
				{
					SkillDesc+="\n\n[Level "+(CurrentLevel + 1)+"]\n" + GetDescLevel(CurrentLevel + 1);
				}
			}
		}
		catch
		{
			MonoBehaviour.print(SkillName + "'s skill description could not be loaded");
		}
	}

    public Skill Clone()
    {
        Skill temp = MakeClone();
        try
        {
            ((ActiveSkill)temp).Setup();
        }
        catch { }
        return temp;
    }

    protected abstract Skill MakeClone();

	public abstract string GetDescLevel(int lvl);
}
