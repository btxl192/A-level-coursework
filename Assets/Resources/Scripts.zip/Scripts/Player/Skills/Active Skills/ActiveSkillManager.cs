﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActiveSkillManager : MonoBehaviour {

    static List<string> ActiveSkillNames = new List<string>();
    static List<string> BoundKeys = new List<string>();

    protected void Start () 
	{
        for (int a = 0; a < SkillManager.SkillDict.Count; a++)
        {
            if (SkillManager.SkillDict[a].IsActiveSkill)
            {
                KeyBindings.AddAction(SkillManager.SkillDict[a].SkillName);
                ActiveSkillNames.Add(SkillManager.SkillDict[a].SkillName);
            }            
        }
	}

    public static void UpdateKeys()
    {
        BoundKeys = new List<string>();
        foreach (string action in KeyBindings.KeyBinds.Keys)
        {
            if (ActiveSkillNames.Contains(action))
            {
                BoundKeys.Add(KeyBindings.KeyBinds[action]);
            }
        }
    }

	void Update()
    {
        foreach(string keypress in BoundKeys)
        {
            if (keypress != "")
            {
                if (Input.GetKeyDown((KeyCode)System.Enum.Parse(typeof(KeyCode), keypress)))
                {
                    foreach (Skill s in SkillManager.Skills.Values)
                    {
                        try
                        {
                            if (s.IsActiveSkill)
                            {
                                if (keypress == KeyBindings.KeyBinds[s.SkillName] && s.Level > 0 && ((ActiveSkill)s).HoldKey == false)
                                {
                                    ((ActiveSkill)s).Activate();
                                }
                            }
                        }
                        catch
                        {
                            print("couldn't cast skill: " + s.SkillName);
                            throw;
                        }
                    }
                }
                else if (Input.GetKey((KeyCode)System.Enum.Parse(typeof(KeyCode), keypress)))
                {
                    foreach (Skill s in SkillManager.Skills.Values)
                    {
                        try
                        {
                            if (s.IsActiveSkill)
                            {
                                if (keypress == KeyBindings.KeyBinds[s.SkillName] && s.Level > 0 && ((ActiveSkill)s).HoldKey == true)
                                {
                                    ((ActiveSkill)s).Activate();
                                }
                            }
                        }
                        catch
                        {
                            print("couldn't cast skill: " + s.SkillName);
                            throw;
                        }
                    }
                }
            }
        }

    }

}
