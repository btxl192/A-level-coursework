﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Smog : ActiveSkill {

    public GameObject ItemReference;
	private GameObject SmogCloud;
	private PlayerStats player;

    public Smog(int Lv, int MaxLv) : base(Lv, MaxLv)
    {
    }

    public override SkillSets SkillSet{get {return SkillSets.Pyromaniac; }}

    public override bool IsActiveSkill
    {
        get
        {
            return true;
        }
    }

    public override string SkillName { get { return "Smog"; } }

    public override int ManaCost
    {
        get
        {
            return 20;
        }
    }

    public override bool HoldKey
    {
        get
        {
            return false;
        }
    }

    public override void Setup()
	{
		ItemReference = Resources.Load(FileDir.Sphere) as GameObject;
		SmogCloud = MonoBehaviour.Instantiate(ItemReference);
		player = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerStats>();
	}

	int damage(int lvl)
	{
		return (int)(player.Combat.damage * (0.75+0.05*lvl)); 
	}

	public override string GetDescLevel(int lvl)
	{
		return "Creates a poisonous gas cloud of " + GetSmogSize(lvl).localScale.x + " units in diameter." + "\nDoes "+(75+5*lvl) + "% ("+damage(lvl)+") of your final damage as poison damage.";
	}

	public Transform GetSmogSize(int lvl)
	{
		SmogCloud.transform.localScale = ItemReference.transform.localScale * Mathf.Pow(1.05f,lvl);
		return SmogCloud.transform;
	}

	public override void UseSkill()
	{
		GameObject WorldSmogCloud = MonoBehaviour.Instantiate(SmogCloud);
		WorldSmogCloud.transform.localScale = GetSmogSize(Level).localScale;
		WorldSmogCloud.GetComponent<Renderer> ().material.color = new Color (0f,0f,0f,0.7f);
		WorldSmogCloud.transform.position = Player.transform.position;
		WorldSmogCloud.AddComponent<SmogGas>();
        WorldSmogCloud.GetComponent<SmogGas>().SetLevel(Level);
		WorldSmogCloud.GetComponent<SmogGas>().SetDamage(damage(Level));
		WorldSmogCloud.SetActive(true);
	}

    protected override Skill MakeClone()
    {
        return new Smog(this.CurrentLevel, this.MaxLevel);
    }
}
