﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blizzard : ActiveSkill {

	public override SkillSets SkillSet {get {return SkillSets.Infrigidare; }}

    public override bool IsActiveSkill
    {
        get
        {
            return true;
        }
    }

    public override string SkillName { get { return "Blizzard"; } }

    public override int ManaCost
    {
        get
        {
            return 10;
        }
    }

    public override bool HoldKey
    {
        get
        {
            return false;
        }
    }

    public Blizzard(int Lv, int MaxLv) : base(Lv, MaxLv)
    {
    }

    float dist(int lvl)
	{
		return lvl+4;
	}

	public override string GetDescLevel(int lvl)
	{
		return "Slows down enemies that are " + dist(lvl).ToString() + " units away from you";
	}

	public override void UseSkill()
	{
		foreach(GameObject enemy in Enemies.GetEnemies())
		{
			if(Vector3.Distance(enemy.transform.position, Player.transform.position) <= dist(Level))
			{
				enemy.GetComponent<Statuses>().ApplyStatus(Statuses.MakeStatus(Statuses.statuses.Slow,Level), null);
			}
		}
	}

    protected override Skill MakeClone()
    {
        return new Blizzard(this.CurrentLevel, this.MaxLevel);
    }
}
