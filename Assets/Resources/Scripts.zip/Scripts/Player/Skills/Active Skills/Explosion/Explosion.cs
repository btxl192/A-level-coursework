﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Explosion : ActiveSkill {

	private GameObject ItemReference;
	private GameObject fireball;
    
	public override SkillSets SkillSet {get {return SkillSets.Pyromaniac; }}

    public override bool IsActiveSkill
    {
        get
        {
            return true ;
        }
    }

    public override string SkillName { get { return "Explosion"; } }

    public override int ManaCost
    {
        get
        {
            return 5;
        }
    }

    public override bool HoldKey
    {
        get
        {
            return false;
        }
    }

    public Explosion(int Lv, int MaxLv) : base(Lv, MaxLv)
    {
    }

    public override void Setup()
	{
		ItemReference = Resources.Load(FileDir.FireBall) as GameObject;
		fireball = MonoBehaviour.Instantiate(ItemReference);
	}

	public override string GetDescLevel(int lvl)
	{
		return "Does "+(50+5*(lvl-1))+"% of your final damage (" + (int)(PStats.Combat.damage * (0.5 + 0.05*(lvl-1))) + ") on impact and "+(150+5*(lvl-1))+"% of your final damage (" + (int)(PStats.Combat.damage*(1.5+0.05*(lvl-1))) + ") as splash damage.";
	}

	public override void UseSkill()
	{
		fireball.GetComponent<GenericProjectile>().Shoot(ItemReference,Player,null, Level);
	}

    protected override Skill MakeClone()
    {
        return new Explosion(this.CurrentLevel, this.MaxLevel);
    }
}
