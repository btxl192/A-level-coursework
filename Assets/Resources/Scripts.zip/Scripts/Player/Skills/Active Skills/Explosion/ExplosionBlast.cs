﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplosionBlast : MonoBehaviour {

	private int dmg;

	void Awake () 
	{
		this.gameObject.AddComponent<FadeOut>().FadePeriod = 1;
	}
		
	void OnTriggerEnter(Collider other)
	{
		if (other.GetComponent<GenericEnemy> () != null) 
		{
			other.GetComponent<GenericEnemy> ().TakeDamage (dmg);
		}
	}

	public void SetDamage(int damage)
	{
		dmg = damage;
		this.gameObject.SetActive (true);
	}
}
