﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplosionFireball : GenericProjectile
{
    public int Level
    {
         get;
         protected set;
    }

    protected override void OnCollide(Collider other)
	{
		GameObject EXPLOSION = Instantiate(Resources.Load(FileDir.Sphere) as GameObject);
		EXPLOSION.transform.position = other.transform.position;
		EXPLOSION.AddComponent<ExplosionBlast>();
		EXPLOSION.GetComponent<ExplosionBlast>().SetDamage((int)(GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerStats>().Combat.damage*(1.5+0.05*(Level-1))));
	}
}
