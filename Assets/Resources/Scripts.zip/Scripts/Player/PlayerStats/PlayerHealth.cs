﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealth : MonoBehaviour {

    public int maxhealth { get; private set; }
    public int health { get; private set; }

    void Start ()
    {
        health = 100;
        maxhealth = 100;
    }

    public void ChangeHealth(int amount)
    {
        if (health + amount > maxhealth)
        {
            health = maxhealth;
        }
        else
        {
            health += amount;
        }
    }

    private List<int> FlatHPBonuses = new List<int>();
    private List<float> MultHPBonuses = new List<float>();
    public void AddFlatHP(int i)
    {
        FlatHPBonuses.Add(i);
    }

    public void AddMultHP(float f)
    {
        MultHPBonuses.Add(f);
    }
}
