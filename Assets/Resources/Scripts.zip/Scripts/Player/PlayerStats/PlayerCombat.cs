﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCombat : MonoBehaviour {

    private GenericWeapon PlayerWeapon;
    private int _damage;
    public int damage
    {
        get
        {
            int d = (int)(_damage * (1 + ((this.gameObject.GetComponent<PlayerStats>().level - 1) * 0.2f)));
            foreach (float mult in MultDamageBonuses)
            {
                d = (int)((float)d * mult);
            }
            foreach (int bonus in FlatDamageBonuses)
            {
                d += bonus;
            }
            return d;
        }
        set
        {
            _damage = value;
        }
    }
    public float attspeed { get; private set; }

    private List<int> FlatDamageBonuses = new List<int>();
    private List<float> MultDamageBonuses = new List<float>();

    public void Start()
    {
        PlayerEquipment.ChangedWeapon += UpdateDamage;
        try
        {
            PlayerWeapon = this.gameObject.GetComponent<PlayerEquipment>().Weapon;
        }
        catch { }
        try
        {
            UpdateDamage(PlayerWeapon.gameObject);
        }
        catch { }
    }

    public void AddFlatDamage(int i)
    {
        FlatDamageBonuses.Add(i);
    }

    public void AddMultDamage(float f)
    {
        MultDamageBonuses.Add(f);
    }

    private List<int> FlatAttSpeedBonuses = new List<int>();
    private List<float> MultAttSpeedBonuses = new List<float>();
    public void AddFlatAttSpeed(int i)
    {
        FlatAttSpeedBonuses.Add(i);
    }

    public void AddMultAttSpeed(float f)
    {
        MultAttSpeedBonuses.Add(f);
    }

    public void UpdateDamage(GameObject weapon)
    {
        if (weapon != null)
        {
            PlayerWeapon = weapon.GetComponent<GenericWeapon>();
        }      
        _damage = PlayerWeapon.damage;
        CalcAttSpeed();
    }

    void CalcAttSpeed()
    {
        attspeed = PlayerWeapon.AttSpeed;
        foreach (int i in FlatAttSpeedBonuses)
        {
            attspeed -= i;
        }
        foreach (float f in MultAttSpeedBonuses)
        {
            attspeed *= f;
        }
    }
}
