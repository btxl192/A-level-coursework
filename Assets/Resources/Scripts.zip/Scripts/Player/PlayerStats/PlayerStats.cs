﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStats : MonoBehaviour {

    public PlayerHealth HP
    {
        get
        {
            return this.gameObject.GetComponent<PlayerHealth>();
        }
        private set
        {
            HP = value;
        }
    }
    public PlayerMana MP
    {
        get
        {
            return this.gameObject.GetComponent<PlayerMana>();
        }
        private set
        {
            MP = value;
        }
    }
    public PlayerCombat Combat
    {
        get
        {
            return this.gameObject.GetComponent<PlayerCombat>();
        }
        private set
        {
            Combat = value;
        }
    }
    public PlayerArmour ArmourVals
    {
        get
        {
            return this.gameObject.GetComponent<PlayerArmour>();
        }
        private set
        {
            ArmourVals = value;
        }
    }

    public int exp {get; private set; }
    public int maxexp {get; private set; }
    public int level {get; private set; }
    public int skillpoints {get; private set; }

    public delegate void BlankEvent();
    public static event BlankEvent CheckStats;

    public delegate void addexpevent(int i);
    public static event addexpevent addexp;
        
    void Start()
    {
        skillpoints = 99;
        level = 1;
        maxexp = (25*(level-1) + 100);
        GenericEnemy.giveexp += receiveexp;
        ExpBar.increaselevel += increaselevel;
        CheckStats();
    }

    void receiveexp(int e)
    {
        exp += e;
        IngameLog.Log("Gained " + e + " exp", Color.yellow);
        addexp(e);
    }

    public void increaselevel()
    {
        exp -= maxexp;
		maxexp = (int)((float)maxexp * 1.25f);
        level += 1;        
        skillpoints += 3;
        Combat.UpdateDamage(null);
        CheckStats();
    }

    public void ChangeSkillPoints(int amount)
    {
        skillpoints += amount;
    }
}
