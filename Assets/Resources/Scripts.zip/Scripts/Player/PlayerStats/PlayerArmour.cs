﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerArmour : MonoBehaviour {

    public delegate void BlankEvent();
    public static event BlankEvent ArmourUpdated;

    private int _armour;
    public int armour
    {
        get
        {

            int a = _armour;
            foreach (float mult in MultArmourBonuses)
            {
                a = (int)((float)a * mult);
            }
            foreach (int bonus in FlatArmourBonuses)
            {
                a += bonus;
            }
            return a;
        }
        set
        {
            _armour = value;
        }
    }
    private GenericArmour PlayerArmourObject;
    private List<int> FlatArmourBonuses = new List<int>();
    private List<float> MultArmourBonuses = new List<float>();

    void Start ()
    {
        PlayerEquipment.ChangedArmour += UpdateArmour;
        try
        {
            PlayerArmourObject = this.gameObject.GetComponent<PlayerEquipment>().ArmourObject.GetComponent<GenericArmour>();
        }
        catch { }
    }

    public void AddFlatArmour(int i)
    {
        FlatArmourBonuses.Add(i);
    }

    public void AddMultArmour(float f)
    {
        MultArmourBonuses.Add(f);
    }

    void UpdateArmour(GameObject a)
    {
        PlayerArmourObject = a.GetComponent<GenericArmour>();
        armour = PlayerArmourObject.Armour;
        ArmourUpdated();
    }
}
