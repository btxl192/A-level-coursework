﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMana : MonoBehaviour {

    public int maxmana { get; private set; }
    public int mana { get; private set; }

    void Start ()
    {
        mana = 100;
        maxmana = 100;
    }

    private List<int> FlatMPBonuses = new List<int>();
    private List<float> MultMPBonuses = new List<float>();
    public void AddFlatMP(int i)
    {
        FlatMPBonuses.Add(i);
    }

    public void AddMultMP(float f)
    {
        MultMPBonuses.Add(f);
    }

    public void ChangeMana(int amount)
    {
        if (mana + amount > maxmana)
        {
            mana = maxmana;
        }
        else
        {
            mana += amount;
        }
    }
}
