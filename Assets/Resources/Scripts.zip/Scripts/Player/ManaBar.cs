﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ManaBar : MonoBehaviour {

	private Slider manabar;
	private Text mananum;
	private PlayerStats player;

	void Start () 
	{
		player = GameObject.FindGameObjectWithTag ("Player").GetComponent<PlayerStats>();
		manabar = this.gameObject.GetComponent<Slider>();
		mananum = this.gameObject.GetComponentInChildren<Text> ();
		manabar.maxValue = player.MP.maxmana;
	}

	void Update () 
	{
		manabar.value = player.MP.mana;
		mananum.text = player.MP.mana + "/" + player.MP.maxmana;
	}
}
