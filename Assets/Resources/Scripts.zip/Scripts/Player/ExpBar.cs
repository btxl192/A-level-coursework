﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class ExpBar : MonoBehaviour {

	private Slider expbar;
	private Text expnum;
	private PlayerStats player;

	public delegate void increaselevelevent();
	public static event increaselevelevent increaselevel;
	
	void Start () 
	{
		player = GameObject.FindGameObjectWithTag ("Player").GetComponent<PlayerStats>(); //finds the player
		expbar = this.gameObject.GetComponent<Slider>();
		expnum = this.gameObject.GetComponentInChildren<Text> ();
		expbar.maxValue = player.maxexp;
		PlayerStats.addexp += addexpPROC; 
		expnum.text = player.exp + "/" + player.maxexp + "  Lv. " + player.level;
	}

	void addexpPROC(int exp)
	{
		StartCoroutine (addexp (exp));
	}

	IEnumerator addexp(int exp)
	{
		expnum.text = player.exp + "/" + player.maxexp + "  Lv. " + player.level;
		for(int a = 0; a < exp; a++)
		{
			expbar.value+=1;
			yield return new WaitForSeconds (0.005f);
		}
		while(player.exp>=player.maxexp)
		{
			expbar.value = 0f;
			player.increaselevel();
			expbar.maxValue = player.maxexp;
			expnum.text = player.exp + "/" + player.maxexp + "  Lv. " + player.level;
		}
	}
}