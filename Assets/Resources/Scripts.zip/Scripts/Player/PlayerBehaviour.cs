﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerBehaviour : MonoBehaviour {

	private float _atttimer;

	public GameObject lockedon { get; set; }

    private bool invul;

    private PlayerStats PStats;
	private PlayerEquipment Eq;

	GameObject _Interacting;
	public GameObject Interacting
	{
		get {return _Interacting;}
		set {
			try{_Interacting = value;}
			catch{print("ERROR in PlayerBehaviour: couldn't set interacting value");}}
	}

	void Start () 
	{
        PStats = this.gameObject.GetComponent<PlayerStats>();
		Eq = this.gameObject.GetComponent<PlayerEquipment>();

    }

	void Update()
	{
		if(!Pause.Paused)
		{
			if (PStats.HP.health <= 0) //checks if the player is dead
			{
				this.gameObject.GetComponent<PlayerMovement>().enabled = false;
			}
			else
			{
				if (_atttimer <= PStats.Combat.attspeed) //counter used to keep track of the last time the player attacked. only increments if the last time the player attacked is less than the attack speed to ensure no overflows happen
				{
					_atttimer += Time.deltaTime;
				}
				if (KeyBindings.KeyPressed("Shoot") && _atttimer >= PStats.Combat.attspeed && !MerchantUI.CurrentlyOpen) //checks if the player can attack yet and if the fire button is pressed
				{
					_atttimer = 0; //resets attack timer
					Eq.Weapon.GetComponent<GenericProjectile>().Shoot(Eq.WeaponObject, this.gameObject, lockedon, PStats.Combat.damage);
				}
			} 
		}

	}

	public void takedamage(int d)
	{
		StartCoroutine (playerhit (d));
	}

	IEnumerator playerhit(int d)
	{
		if (!invul)
		{
            Color temp = this.GetComponent<Renderer>().material.color;
            float damagereduc = (float)PStats.ArmourVals.armour / (300f + (float)PStats.ArmourVals.armour);
            PStats.HP.ChangeHealth(-(int)((float)d * (1f - damagereduc)));
            invul = true;
            this.GetComponent<Renderer>().material.color = new Color(0f, 255f, 0f);
            yield return new WaitForSeconds(1f);
            invul = false;
            this.GetComponent<Renderer>().material.color = temp;
        }
	}
}
