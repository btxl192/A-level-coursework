﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {

	public float speed;
    private bool MovementEnabled;
	private int groundmask;
	private GameObject player;
	private Vector3 direction;
	private bool canjump;
    private Rigidbody playerrb;
    
	public delegate void sendangle(Quaternion a);
    public static event sendangle sendA;

	public delegate void sendpos(Vector3 P);
	public static event sendpos sendPos;
	
	void Start () 
	{
		player = this.gameObject;
        playerrb = player.GetComponent<Rigidbody>();
		groundmask = LayerMask.GetMask ("Ground");
		canjump = true;
        MovementEnabled = true;
	}

	void Update()
	{       
		if (!Pause.Paused && MovementEnabled)
		{
			if (Input.GetKeyDown(KeyCode.Space) && canjump) //Checks if the player is able to jump
			{
				jump();
			}
			MoveAndRotate();
		}
    }

	void MoveAndRotate()
	{
		float horiz = Input.GetAxisRaw ("Horizontal");
		float verti = Input.GetAxisRaw ("Vertical");
		direction = new Vector3 (horiz, 0f, verti); 
		playerrb.MovePosition (player.transform.position + direction.normalized * speed* 0.01f);
        Ray mouseray = Camera.main.ScreenPointToRay(Input.mousePosition); 
		RaycastHit rayhit; //used for storing the ray once it hits the groundmask
		Vector3 facedirection;
		Quaternion facerotation = Quaternion.identity;
		if (player.GetComponent<PlayerBehaviour>().lockedon != null) //checks if the player is locked on to an enemy
		{
			facedirection = (player.GetComponent<PlayerBehaviour>().lockedon.transform.position - player.transform.position).normalized; //gets the vector that points from the player to the enemy then normalises it so that the value is only the direction, not the magnitude
			facedirection.y = 0f; //this is here to prevent the cube from tipping
			facerotation = Quaternion.LookRotation (facedirection);
			playerrb.MoveRotation (facerotation); 
		}
		else if (Physics.Raycast (mouseray, out rayhit, 100f, groundmask)) //if the player is not locked on, a check is done to see if the ray from the mouse hits the gruondmask. 
		{
			facedirection = rayhit.point - player.transform.position; //gets the vector that points from the player to the point that the ray from the mouse hits
			facedirection.y = 0f;
			facerotation = Quaternion.LookRotation (facedirection);
			playerrb.MoveRotation (facerotation);
		}
		sendA(facerotation);
		sendPos (player.transform.position);
	}

	void jump()
	{
		playerrb.AddForce (Vector3.up * 50f);
		canjump = false;
	}

	void OnCollisionEnter(Collision other)
	{
		if (other.gameObject.CompareTag ("Ground"))
		{
			canjump = true;
		}

		if (other.gameObject.CompareTag ("Enemy"))
		{
            StartCoroutine(DisableMovement(0.2f));
            //print((player.transform.position - other.transform.position).normalized);
            playerrb.AddForce((player.transform.position - other.transform.position).normalized * 50f);
        }
	}


    IEnumerator DisableMovement(float time)
    {
        MovementEnabled = false;
        yield return new WaitForSeconds(time);
        MovementEnabled = true;
    }
}
