﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInventory : MonoBehaviour {

    [SerializeField]
    private List<GameObject> _inventory = new List<GameObject>();
    public List<GameObject> inventory { get { return _inventory;  } }
	private int maxitems;
	public int Gold;

    private PlayerStats PStats;
	private PlayerEquipment Eq;

	public delegate void ChangedEQevent();
	public static event ChangedEQevent ChangedEQ;

    public delegate void updateinv();
    public static event updateinv updatei;

	void Start () {
		Gold = 1000;
		maxitems = 50;
		EquipButton.ChangeEq += ChangeEquipment;
		EquipButton.UseItem += UseItem;
		PStats = this.gameObject.GetComponent<PlayerStats>();
		Eq = this.gameObject.GetComponent<PlayerEquipment>();
	}

	public void additem(GameObject i)
    {
		if (CheckStackableItem(i) != -1)
		{
			_inventory[CheckStackableItem(i)].GetComponent<StackableItem>().ChangeAmount(i.GetComponent<StackableItem>().Amount);
		}
		else
		{
			_inventory.Add(i);
		}  
		string message;
		message = "Added " + i.GetComponent<GenericItem>().itemname;
		if(i.GetComponent<StackableItem>() != null)
		{
			message += "(" + i.GetComponent<StackableItem>().Amount + ") ";
		}
		message += " to inventory";
		IngameLog.Log(message, Color.white);
		updatei();
    }

    public void removeat(int i)
    {
        _inventory.RemoveAt(i);
        updatei();
    }

    public bool isinvfull()
    {
        return _inventory.Count == maxitems;
    }

	public int CheckItem(GameObject i)
	{
		foreach (GameObject item in _inventory)
		{
			if (item.GetComponent<GenericItem> ().itemname == i.GetComponent<GenericItem> ().itemname)
			{
				return _inventory.IndexOf(item);
			} 
		}
		return -1;
	}

	public void ChangeEquipment(int i)
	{
		try
		{
			GameObject PrevEq;
			Eq.Equip(_inventory[i], out PrevEq);
			_inventory[i] = PrevEq;
			if(_inventory[i] == null)
			{
				_inventory.RemoveAt(i);
			}
			ChangedEQ();
		}
		catch
		{
			print("ERROR: Couldn't change equipment");
		}
	}

	public void UseItem(int i)
	{
		if (_inventory [i].GetComponent<HealingItem> () != null)
		{
			if (PStats.HP.health < PStats.HP.maxhealth)
			{
				PStats.HP.ChangeHealth(_inventory [i].GetComponent<HealingItem> ().HpHealAmount);
			}
			if (PStats.MP.mana < PStats.MP.maxmana)
			{
				PStats.MP.ChangeMana(_inventory [i].GetComponent<HealingItem> ().MpHealAmount);
			}
			_inventory [i].GetComponent<HealingItem> ().ChangeAmount(-1);
			if (_inventory [i].GetComponent<HealingItem> ().Amount <= 0)
			{
				Destroy (_inventory [i]);
				_inventory.RemoveAt (i);
			}
		}
	}

	public int CheckStackableItem(GameObject h)
	{
		if(h.GetComponent<StackableItem>() != null)
		{
			foreach(GameObject g in _inventory)
			{
				if(g.GetComponent<GenericItem>().itemname == h.GetComponent<GenericItem>().itemname)
				{
					return _inventory.IndexOf(g);
				}
			}
		}
		return -1;
	}
}
