﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour {

	private Slider healthbar;
	private Text healthnum;
	private PlayerStats player;

	void Start () 
	{
		player = GameObject.FindGameObjectWithTag ("Player").GetComponent<PlayerStats>();
		healthbar = this.gameObject.GetComponent<Slider>();
		healthnum = this.gameObject.GetComponentInChildren<Text> ();
		healthbar.maxValue = player.HP.maxhealth;
	}

	void Update () 
	{
		healthbar.value = player.HP.health;
		healthnum.text = player.HP.health + "/" + player.HP.maxhealth;
	}
}
