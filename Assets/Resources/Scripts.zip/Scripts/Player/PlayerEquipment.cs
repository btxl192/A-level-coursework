﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerEquipment : MonoBehaviour {

	[SerializeField]
	public GameObject WeaponObject
	{
		get;
		private set;
	}

	public GenericWeapon Weapon
	{
		get {return WeaponObject.GetComponent<GenericWeapon>();}
	}

	[SerializeField]
	public GameObject SkillCore
	{
		get;
		private set;
	}
	[SerializeField]
	public GameObject ArmourObject
	{
		get;
		private set;
	}
	public GenericArmour Armour
	{
		get {return ArmourObject.GetComponent<GenericArmour>(); }
	}

	public delegate void ChangedEq(GameObject eq);
	public static event ChangedEq ChangedWeapon;
    public static event ChangedEq ChangedArmour;
    public static event ChangedEq ChangedSkillCore;

    void Awake () 
	{
		if (WeaponObject == null)
		{
			WeaponObject = Resources.Load(FileDir.BasicProjectile) as GameObject;
		}
		//if (SkillCore == null)
		//{
		//	SkillCore = Resources.Load(FileDir.BaseSkillCore) as GameObject;
		//}
	}

	public void Equip(GameObject Equipment, out GameObject PrevEquipment)
	{
		if(Equipment.GetComponent<GenericWeapon>() != null)
		{
			PrevEquipment = WeaponObject;
			WeaponObject = Equipment;
			ChangedWeapon(Equipment);
		}
		else if(Equipment.GetComponent<GenericArmour>() != null)
		{
			PrevEquipment = ArmourObject;
			ArmourObject = Equipment;
            ChangedArmour(Equipment);
		}
		else if(Equipment.GetComponent<SkillCore>() != null)
		{
			PrevEquipment = SkillCore;
			SkillCore = Equipment;
            ChangedSkillCore(Equipment);
		}
		else
		{
			PrevEquipment = null;
		}
	}
}
