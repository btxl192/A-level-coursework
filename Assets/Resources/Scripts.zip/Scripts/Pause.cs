﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pause : MonoBehaviour {

	private static bool _Paused;
	public static bool Paused
	{
		get {return _Paused;}
	}

	protected virtual void Start () 
	{
		GenericMenu.pauser += PauseGame;
        GenericMenu.unpauser += ResumeGame;
		GenericMenu2.pauser += PauseGame;
		GenericMenu2.unpauser += ResumeGame;
	}

	protected void ResumeGame() 
	{
		Time.timeScale = 1;
		_Paused = false;
	}

	protected void PauseGame()
	{
		Time.timeScale = 0;
		_Paused = true;
	}

}
