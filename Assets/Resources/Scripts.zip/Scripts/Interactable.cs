﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public abstract class Interactable : MonoBehaviour {

	protected GameObject Player;
	protected bool CanInteract;
	protected GameObject PopupReference;
	protected GameObject Popup;
	protected Vector3 PopupOffset;
	protected bool Interacting;
	protected string PopupText;

	protected virtual void Awake () 
	{
		Player = GameObject.FindGameObjectWithTag("Player");
		try{
		PopupReference = Resources.Load(FileDir.InteractablePopup) as GameObject;
		Popup = Instantiate(PopupReference);
		Popup.SetActive(false);}
		catch{print("ERROR in interactable: couldn't load trade popup");}	
		PopupOffset = new Vector3(0f,20f,0f);
	}

	void Update () {
		try
		{
			if(Vector3.Distance(transform.position, Player.transform.position) < 0.5f)
			{
				if(CanInteract)
				{
					Player.GetComponent<PlayerBehaviour>().Interacting = this.gameObject;
					CanInteract = false;
				}
				if(Player.GetComponent<PlayerBehaviour>().Interacting == this.gameObject && !Pause.Paused)
				{
					if(!Interacting)
					{
                        Popup.GetComponentInChildren<Text>().text = PopupText + " [" + KeyBindings.KeyBinds["Interact"] + "]";
                        Popup.SetActive(true);
					}
					else
					{
						Popup.SetActive(false);
					}
					Popup.GetComponentsInChildren<RectTransform>()[1].position = Camera.main.WorldToScreenPoint(transform.position) + PopupOffset;
					if (KeyBindings.KeyPressed("Interact"))
					{
						Interacting = true;
						Interact();
					}
				}
				else
				{
					Popup.SetActive(false);
				}
			}
			else
			{
				Popup.SetActive(false);
				CanInteract = true;
				Interacting = false;
				OutOfRange();
			}
		}
		catch {print("ERROR in interactable"); throw;}		
	}

	protected abstract void Interact();
	protected abstract void OutOfRange();
}
