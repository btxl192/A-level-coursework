﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Minimap : MonoBehaviour {

    private Image _player;
	private Transform map;
	private Vector3 playerposition;
	private static List<MinimapIcon> enemyicons = new List<MinimapIcon> ();
    private static Dictionary<GameObject, GameObject> itemicons = new Dictionary<GameObject, GameObject>();
    private static Dictionary<GameObject, List<GameObject>> groundlines = new Dictionary<GameObject, List<GameObject>>();
    private float ZoomLevel;
    public static Queue<GameObject> GroundCreateQueue = new Queue<GameObject>();

    struct MinimapIcon
    {
        public GameObject Icon;
        public int Index;
    }

    void Awake () 
    {
        _player = Instantiate((Resources.Load(FileDir.PlayerMinimapIcon) as GameObject).GetComponent<Image>(), this.gameObject.transform);
		_player.GetComponent<RectTransform> ().anchorMax = new Vector2(0.5f,0.5f);
		_player.GetComponent<RectTransform> ().anchorMin = new Vector2(0.5f,0.5f);
        _player.GetComponent<RectTransform>().anchoredPosition = new Vector3(0f, 0f, 0f);
        PlayerMovement.sendA += GetAngle;
		PlayerMovement.sendPos += GetPlayerPos;
        GenericEnemy.SendPos += UpdateEnemy;
        Ground.SendPos += UpdateGroundLines;
        Enemies.CreatedEnemy += ShowEnemy;
        Pickup.Created += ShowItem;
        Pickup.SendPos += UpdateItemIcons;
		foreach (GameObject e in Enemies.GetEnemies()) 
		{
			ShowEnemy (e);
		}
        ZoomLevel = 10f;
	}

    public float GetZoom()
    {
        return ZoomLevel;
    }

    public void SetZoom(float f)
    {
        ZoomLevel = f;
    }

    private void Update()
    {
        if (GroundCreateQueue.Count > 0)
        {
            CreateGroundLines(GroundCreateQueue.Dequeue());
        }
    }

    void GetAngle(Quaternion a)
    {
		a.eulerAngles = new Vector3 (0f, 0f, -a.eulerAngles.y);
		_player.transform.rotation = a;
    }

	void GetPlayerPos(Vector3 p)
	{
		playerposition = p;
	}

	public void ShowEnemy(GameObject e)
	{
		enemyicons.Add (CreateIcon(Instantiate (Resources.Load (FileDir.EnemyIcon) as GameObject, this.gameObject.transform),Enemies.GetEnemies().IndexOf(e)));
	}

	void UpdateEnemy(int index)
	{
        try
        {
            enemyicons[index].Icon.GetComponent<RectTransform>().anchoredPosition = new Vector3((Enemies.GetEnemies()[index].transform.position.x - playerposition.x) * ZoomLevel, (Enemies.GetEnemies()[index].transform.position.z - playerposition.z) * ZoomLevel, enemyicons[index].Icon.GetComponent<RectTransform>().position.z);
        }
        catch
        {
        }
    }

    MinimapIcon CreateIcon(GameObject icon, int index)
	{
        MinimapIcon temp;
		temp.Icon = icon;
		temp.Index = index;
		return temp;
	}

    public static void RemoveEnemyIcon(int index)
	{
		Destroy (enemyicons [index].Icon);
		enemyicons.RemoveAt (index);
	}

    public void CreateGroundLines(GameObject parent)
    {
        groundlines.Add(parent, SameGroundLines());
    }

    List<GameObject> HighGroundLines()
    {
        List<GameObject> temp = new List<GameObject>();
        for (int a = 0; a < 4; a++)
        {
            temp.Add(Instantiate(Resources.Load(FileDir.HighGroundOutline) as GameObject, this.gameObject.transform));
            temp[a].transform.transform.SetAsFirstSibling();
        }
        return temp;
    }

    List<GameObject> SameGroundLines()
    {
        List<GameObject> temp = new List<GameObject>();
        for (int a = 0; a < 4; a++)
        {
            temp.Add(Instantiate(Resources.Load(FileDir.GroundOutline) as GameObject, this.gameObject.transform));
            temp[a].transform.transform.SetAsFirstSibling();
        }
        return temp;
    }

    List<GameObject> LowGroundLines()
    {
        List<GameObject> temp = new List<GameObject>();
        for (int a = 0; a < 4; a++)
        {
            temp.Add(Instantiate(Resources.Load(FileDir.LowGroundOutline) as GameObject, this.gameObject.transform));
            temp[a].transform.transform.SetAsFirstSibling();
        }
        return temp;
    }

    void DestroyGroundLines(List<GameObject> groundlines)
    {
        foreach (GameObject g in groundlines)
        {
            Destroy(g);
        }
    }

    public void UpdateGroundLines(GameObject ground, List<Vector3> points, float height)
    { 
        try
        { 
            if (System.Math.Round(ground.GetComponent<Ground>().PrevY,2) != System.Math.Round(ground.transform.position.y - playerposition.y,2))
            {
                DestroyGroundLines(groundlines[ground]);
                if (ground.transform.position.y + 0.5f * height - playerposition.y + 0.1f >= 0.09)
                {
                    groundlines[ground] = HighGroundLines();
                }
                else if (ground.transform.position.y + 0.5f * height - playerposition.y + 0.1f < -0.11)
                {
                    groundlines[ground] = LowGroundLines();
                }
                else
                {
                    groundlines[ground] = SameGroundLines();
                }
            }
            ground.GetComponent<Ground>().PrevY = ground.transform.position.y - playerposition.y;
            for (int a = 0; a < 4; a++)
            {
                GameObject line = groundlines[ground][a];
                line.GetComponent<RectTransform>().anchoredPosition = new Vector3((points[a].x - playerposition.x) * ZoomLevel, (points[a].z - playerposition.z) * ZoomLevel, points[a].z);
                if (a < 2)
                {
                    line.GetComponent<RectTransform>().sizeDelta = new Vector2(Mathf.Sqrt((points[2] - points[3]).sqrMagnitude) * ZoomLevel, 0.5f);
                    line.GetComponent<RectTransform>().rotation = Quaternion.Euler(0f, 0f, ground.transform.rotation.eulerAngles.y);
                }
                else
                {
                    line.GetComponent<RectTransform>().sizeDelta = new Vector2(Mathf.Sqrt((points[0] - points[1]).sqrMagnitude) * ZoomLevel, 0.5f);
                    line.GetComponent<RectTransform>().rotation = Quaternion.Euler(0f, 0f, -ground.transform.rotation.eulerAngles.y);
                }        
            }
        }
        catch { print("MINIMAP: couldn't update lines"); }
    }

    void ShowItem(GameObject item)
    {
        itemicons.Add(item, Instantiate(Resources.Load(FileDir.ItemMinimapIcon) as GameObject, this.transform));
    }

    public static void DestroyItemIcon(GameObject item)
    {
        Destroy(itemicons[item]);
        itemicons.Remove(item);
    }

    void UpdateItemIcons(GameObject item)
    {
        try
        {
            itemicons[item].GetComponent<RectTransform>().anchoredPosition = new Vector3((item.transform.position.x - playerposition.x) * ZoomLevel, (item.transform.position.z - playerposition.z) * ZoomLevel, item.transform.position.z);
        }
        catch
        { }
    }
}
