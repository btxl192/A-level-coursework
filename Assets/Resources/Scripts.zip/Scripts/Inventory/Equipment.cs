﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Equipment : GenericMenuPart {

	private Text thistext;
	private PlayerStats player;
	private GenericItem Weapon;
	public override float height
	{
		get
		{
			return bgheight;
		}
	}
	public override float width
	{
		get
		{
			return bgwidth * 0.5f;
		}
	}

	protected override void Start () 
	{
		base.Start ();
		thistext = this.gameObject.GetComponent<Text> ();
		player = GameObject.FindGameObjectWithTag ("Player").GetComponent<PlayerStats>();
		PlayerInventory.ChangedEQ += UpdateText;
		ExpBar.increaselevel += UpdateText;
		PlayerArmour.ArmourUpdated +=CheckArmour;
        PlayerStats.CheckStats += UpdateText;
		UpdateText();
	}

	void UpdateText () 
	{
        Weapon = player.GetComponent<PlayerEquipment>().WeaponObject.GetComponent<GenericItem>();
		string WeaponName = Weapon.itemname;
		thistext.text = "Current Weapon: " + WeaponName + "\nDamage: " + player.Combat.damage.ToString();
		thistext.text += "\nAttack Speed: " + player.Combat.attspeed;
        thistext.text += "\nArmour: " + player.ArmourVals.armour;
	}

	void CheckArmour()
	{
		thistext.text += "\nArmor: " + player.GetComponent<PlayerStats>().ArmourVals.armour;	
	}


}
