﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PrevPageButton : GenericMenuPart {

	private Button thisbutton;

	public override float width
	{
		get 
		{
			return bgwidth * 0.096f;
		}
	}

	public override float height
	{
		get
		{
			return bgheight * 0.093f;
		}
	}
	protected override void Start () 
	{
		base.Start ();
		thisbutton = this.gameObject.GetComponent<Button> ();
		thisbutton.onClick.AddListener (RunEvent);
	}

	protected override void UpdateDimensions()
	{
		base.UpdateDimensions();
		this.gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector3 (-bgwidth*0.3f + width, bgheight*0.01f, 0f);
	}

	void RunEvent()
	{
		PrevPage ();
	}

	public delegate void PrevPageEvent();
	public static event PrevPageEvent PrevPage;
}
