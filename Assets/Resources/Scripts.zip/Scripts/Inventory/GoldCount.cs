﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoldCount : MonoBehaviour {
	
	private PlayerInventory player;

	void Awake()
	{
		player = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerInventory>();
	}

	void Update () 
	{
		this.gameObject.GetComponent<UnityEngine.UI.Text>().text = player.Gold.ToString() + " Gold";
	}
}
