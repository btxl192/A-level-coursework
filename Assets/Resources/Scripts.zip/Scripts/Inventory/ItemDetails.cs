﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemDetails : GenericMenuPart {

	public delegate void PassEqEvent(int i);
	public static event PassEqEvent PassEq;

	public delegate void ChangeTextEvent(string t);
	public static event ChangeTextEvent ChangeText;
	
	private Text WholeText;
	private Text textPrefab;

	public override float width
	{
		get
		{
			return bgwidth * 0.4f;
		}
	}

	public override float height
	{
		get
		{
			return bgheight * 0.8f;
		}
	}

	protected override void Start () 
	{
		base.Start ();
		textPrefab = (Resources.Load (FileDir.Text) as GameObject).GetComponent<Text>();
		InvSlot.DisplayDetails += ShowDetails;
		EquipButton.UpdateDetails += ShowDetails;
		Inventory.UpdateInv += Clear;
		WholeText = Instantiate(textPrefab, this.transform);
		this.gameObject.transform.localPosition = new Vector3 (230f, 0f, 0f);
	}

	protected override void UpdateDimensions()
	{
		base.UpdateDimensions();

		WholeText.GetComponent<RectTransform>().sizeDelta = new Vector2(width,height*0.7f);
		WholeText.GetComponent<RectTransform> ().anchorMax = new Vector2 (0.5f,0.5f);
		WholeText.GetComponent<RectTransform> ().anchorMin = new Vector2 (0.5f,0.5f);
		WholeText.GetComponent<RectTransform>().anchoredPosition = new Vector3 (width*0.05f,0f, 0f);
	}

	void ShowDetails(GameObject i, int j)
	{
		if (i != null)
		{
			Clear();
			WholeText.text += "Category: " + i.GetComponent<GenericItem>().category;
            WholeText.text += "\nItem Name: " + i.GetComponent<GenericItem>().itemname;
            WholeText.text += "\n" + i.GetComponent<GenericItem>().desc;
            string category = GenericItem.Categories[i.GetComponent<GenericItem>().category];
            switch (category)
            {
                case "Projectile":
                    ChangeText("Equip");
                    WholeText.text += "\nBase Damage: " + i.GetComponent<GenericWeapon>().damage.ToString();
                    break;
                case "Healing Item":
                    ChangeText("Use");
                    WholeText.text += "\nAmount: " + i.GetComponent<HealingItem>().Amount.ToString();
                    break;
				case "Armour":
					ChangeText("Equip");
                    WholeText.text += "\nBase Armour: " + i.GetComponent<GenericArmour>().Armour.ToString();
                    break;
                case "Skill Core":
                    ChangeText("Equip");
                    WholeText.text += "\nSkills Upgraded: \n";
                    foreach (Skill s in i.GetComponent<SkillCore>().Skills)
                    {
                        WholeText.text += s.SkillName + " (" + s.CurrentLevel + ")\n";
                    }
                    break;
                default:
					ChangeText("");
					break;
            }
            PassEq (j);
		} 
		else
		{
			Clear ();
			ChangeText("");
		}
	}

	void Clear()
	{
		WholeText.text = "";
	}
}
