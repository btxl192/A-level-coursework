﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddSkillButtons : MonoBehaviour {

	[SerializeField]
	private bool _Active;

	void Awake () 
	{
		SkillManager.RunAddSkillButton += UpdateSkills;
        Inventory.OnClose += DestroyButtons;
	}
	
    public void UpdateSkills(List<Skill> Skills)
    {
        DestroyButtons();
        foreach (Skill s in Skills)
        {
			if (s.IsActiveSkill == _Active)
			{
				GameObject tempskill = Instantiate(Resources.Load(FileDir.SkillButton) as GameObject, this.transform);
				tempskill.GetComponent<SkillButton>().SkillID = SkillManager.GetSkillDictKey(s);
			}
        }
    }

    void DestroyButtons()
    {
        foreach (SkillButton g in this.gameObject.GetComponentsInChildren<SkillButton>())
        {
            g.Destroy();
        }
    }
}
