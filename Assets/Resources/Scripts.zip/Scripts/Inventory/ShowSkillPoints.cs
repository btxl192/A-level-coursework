﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShowSkillPoints : MonoBehaviour {

	private PlayerStats PStats;

	void Start () 
	{
		PStats = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerStats>();
	}
	
	void Update () 
	{
		this.GetComponent<UnityEngine.UI.Text>().text = "Skill Points: " + PStats.skillpoints.ToString();
	}
}
