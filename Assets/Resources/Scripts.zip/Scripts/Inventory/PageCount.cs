﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PageCount : GenericMenuPart {

	private static int _PageNum;
	public static int PageNum
	{
		get {return _PageNum;}
	}
	private int MaxPage;
	public delegate void UpdateInvEvent();
	public static event UpdateInvEvent UpdateInv;
	
	public override float height
	{
		get
		{
			return bgheight * 0.08f;
		}
	}

	public override float width
	{
		get
		{
			return bgwidth * 0.07f;
		}
	}

	protected override void Start () 
	{
		base.Start ();
		_PageNum = 1;
		MaxPage = 5;
		NextPageButton.NextPage += NextPage;
		PrevPageButton.PrevPage += PrevPage;
		this.gameObject.GetComponent<Text> ().color = Color.white;
		UpdatePageCount();
	}

	protected override void UpdateDimensions()
	{
		base.UpdateDimensions();
		this.gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector3 (-bgheight*0.15f, 0f, 0f);
	}

	void NextPage()
	{
		if (PageNum < MaxPage)
		{
			_PageNum += 1;
		}
		else
		{
			_PageNum = 1;
		}
		UpdatePageCount();
		UpdateInv ();
	}

	void PrevPage()
	{
		if (PageNum != 1)
		{
			_PageNum -= 1;
		} 
		else
		{
			_PageNum = MaxPage;
		}
		UpdatePageCount();
		UpdateInv ();
	}

	void UpdatePageCount()
	{
		this.gameObject.GetComponent<Text>().text = PageNum + "/" + MaxPage;
	}
}
