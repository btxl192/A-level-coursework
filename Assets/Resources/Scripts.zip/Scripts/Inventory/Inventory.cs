﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : GenericMenu {
	
	public delegate void UpdateInvEvent();
	public static event UpdateInvEvent UpdateInv;

    protected override void Start()
    {
        base.Start();
        TypeOfMenu = "Inventory";
    }

    protected override void AdditionalBehaviourOnOpen()
    {
        UpdateInv();
    }
}
