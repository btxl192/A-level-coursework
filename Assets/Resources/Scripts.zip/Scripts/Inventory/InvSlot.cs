﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class InvSlot : GenericMenuPart {

    public int _invslot; 
    private GameObject _item; 
	private static List<GameObject> invslots = new List<GameObject>();

	public delegate void DisplayDetailsEvent(GameObject i, int j);
	public static event DisplayDetailsEvent DisplayDetails;
	
    private GameObject player;
	private Button thisbutton;

	public override float width
	{
		get
		{
			return bgwidth * 0.3f;
		}
	}

	public override float height
	{
		get
		{
			return bgheight * 0.06f;
		}
	}

	protected override void Start () 
    {
		base.Start ();
        player = GameObject.FindGameObjectWithTag("Player");
        PlayerInventory.updatei += UpdateSlot; //subcribes the subroutine "UpdateSlot" to the event "updatei". This refreshes the inventory slot
		PageCount.UpdateInv += UpdateSlot;
		EquipButton.UpdateInv += UpdateSlot;
		EquipButton.SendSlot += Selected;
		SortInvButton.UpdateInv += UpdateSlot;
		Inventory.UpdateInv += Clear;
		GenericMenu.OnOpen += UpdateSlot;
		thisbutton = this.gameObject.GetComponent<Button>();
		thisbutton.onClick.AddListener (details);
		UpdateSlot ();
		invslots.Add (this.gameObject);
		_invslot = invslots.IndexOf (this.gameObject);
	}

	protected override void UpdateDimensions()
	{
		base.UpdateDimensions();
		this.gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector3 (bgwidth*0.25f,height * ((9-_invslot)-3), 0f);
	}

    void UpdateSlot()
    {
		this.gameObject.GetComponent<Image>().color = Color.white;
        try
        {
			_item = player.GetComponent<PlayerInventory>().inventory[_invslot + (PageCount.PageNum - 1) * 10];
			thisbutton.GetComponentInChildren<Text>().text = _item.GetComponent<GenericItem>().itemname;
            if (WillOverflow())
            {
                thisbutton.GetComponentInChildren<Text>().text += "...";
                while (WillOverflow())
                {
                    thisbutton.GetComponentInChildren<Text>().text = thisbutton.GetComponentInChildren<Text>().text.Remove((thisbutton.GetComponentInChildren<Text>().text.Length - 3),1);                   
                }
            }

            if (_item.GetComponent<HealingItem>() != null)
			{
				thisbutton.GetComponentInChildren<Text>().text += " (" + _item.GetComponent<HealingItem>().Amount + ")";
			}
            this.gameObject.GetComponentInChildren<ItemTypeIcon>().gameObject.GetComponent<RectTransform>().sizeDelta = new Vector2(this.GetComponent<RectTransform>().sizeDelta.y * 0.8f, this.GetComponent<RectTransform>().sizeDelta.y * 0.8f);
            this.gameObject.GetComponentInChildren<ItemTypeIcon>().ChangeItemType(GenericItem.Categories[_item.GetComponent<GenericItem>().category]);
        }
        catch
        {
		 	_item = null;
		 	thisbutton.GetComponentInChildren<Text>().text = "";
            this.gameObject.GetComponentInChildren<ItemTypeIcon>().ChangeItemType(null);
        }
    }

	void details()
	{
		try
		{
			foreach(GameObject slot in invslots)
			{
				slot.GetComponent<Image>().color = Color.white;
			}
			this.gameObject.GetComponent<Image>().color = Color.yellow;
			DisplayDetails(null,-1);
			DisplayDetails (_item, _invslot + (PageCount.PageNum - 1) * 10);
		}
		catch
		{
			print("ERROR: couldn't display _item details");
		}
	}

	void Selected(int i)
	{
		if (_invslot == i)
		{
			this.gameObject.GetComponent<Image>().color = Color.yellow;
		}
	}

	void Clear()
	{
		this.gameObject.GetComponent<Image>().color = Color.white;
	}

    bool WillOverflow()
    {
        try
        {
            return thisbutton.GetComponent<RectTransform>().sizeDelta.x - 15 < LayoutUtility.GetPreferredWidth(thisbutton.GetComponentInChildren<Text>().rectTransform);
        }
        catch
        {
            return false;
        }
    }
}
