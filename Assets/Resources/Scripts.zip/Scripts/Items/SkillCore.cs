﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillCore : GenericItem {

    [SerializeField]
    protected List<Skill> _Skills = new List<Skill>();
    public List<Skill> Skills
    {
        get {return _Skills; }
    }
}
