﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenericItem : MonoBehaviour {

    public enum Rarities
    {
        Common,
        Rare,
        Epic,
        Legendary
    }

	public enum CategoryEnum
	{
		Item,
		Projectile,
		HealingItem,
		Armour,
		SkillCore,
		Weapon,
        Misc
	}

	public static Dictionary<CategoryEnum, string> Categories = new Dictionary<CategoryEnum,string>()
	{
		{CategoryEnum.Item, "Item"},
		{CategoryEnum.Projectile, "Projectile"},
		{CategoryEnum.HealingItem, "Healing Item"},
		{CategoryEnum.Armour, "Armour"},
		{CategoryEnum.SkillCore, "Skill Core"},
		{CategoryEnum.Weapon, "Weapon"},
        {CategoryEnum.Misc, "Misc"}
	};

	[SerializeField]
    protected string _itemname;
	public string itemname
	{
		get {return _itemname; }
	}

	[SerializeField]
    protected string _desc;
	public string desc
	{
		get {return _desc; }
	}

	[SerializeField]
	protected CategoryEnum _category;
	public CategoryEnum category
	{
		get {return _category; }
		protected set {_category = value;}
	}

    [SerializeField]
    protected Rarities _Rarity;
    public Rarities Rarity
    {
        get { return _Rarity; }
        set { _Rarity = value; }
    }

    [SerializeField]
    protected int _Price;
    public int Price
    {
        get
        {
            return _Price;
        }
    }

    public void SetCategory(CategoryEnum Category)
    {
        Category = category;
    }

    public void SetDetails(string ItemName, string ItemDesc)
    {
        _itemname = ItemName;
        _desc = ItemDesc;
    }
}

