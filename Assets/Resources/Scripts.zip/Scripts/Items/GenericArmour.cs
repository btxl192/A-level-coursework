﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenericArmour : GenericItem {

    [SerializeField]
    protected int _Armour;
    public int Armour
    {
        get {return _Armour; }
    }

	protected void Awake () 
	{
		_category = CategoryEnum.Armour;
	}
	
	public void RandomiseStats(GenericItem.Rarities rarity)
	{
		_category = CategoryEnum.Armour;
        _itemname = rarity + " Armour";
		if (rarity == Rarities.Common)
        {
            _Armour = Random.Range(110, 200);
            _desc = "A common piece of armour";
        }
        if (rarity == Rarities.Rare)
        {
            _Armour = Random.Range(210, 300);
            _desc = "A rare piece of armour";
        }
        if (rarity == Rarities.Epic)
        {
            _Armour = Random.Range(310, 600);
            _desc = "An epic piece of armour!";
        }
        if (rarity == Rarities.Legendary)
        {
            _Armour = Random.Range(610, 1000);
            _desc = "A legendary piece of armour!!";
        }
	}
}
