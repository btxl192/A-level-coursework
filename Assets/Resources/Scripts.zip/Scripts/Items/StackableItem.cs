﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StackableItem : GenericItem
{
    [SerializeField]
    protected int _Amount;
    public int Amount
    {
        get
        {
            return _Amount;
        }
        private set
        {
            _Amount = value;
        }
    }

    public void ChangeAmount(int amount)
    {
        Amount += amount;
    }

    public void SetAmount(int amount)
    {
        Amount = amount;
    }

}
