﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoisonArrow : GenericProjectile

{
	protected void Awake()
	{
		damage = 10;
		StatusEffects.Add (Statuses.MakeStatus(Statuses.statuses.Poison, 1));
	}
		
}
