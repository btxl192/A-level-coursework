﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenericProjectile : GenericWeapon {

	protected float lifetime;

    protected void Update()
	{
		if (!Pause.Paused)
		{
			lifetime += Time.deltaTime;
			if (lifetime >= 5f)
			{
				Destroy (this.gameObject); //If the projectile is "alive" for more than 5 seconds, it will be destroyed
			}
		}
	}

    protected override void OnTriggerEnter(Collider other) //OnTriggerEnter is to check if the game object has collided with a trigger
	{
        try
        {
            if (whitelisttags.IndexOf(other.GetComponent<Collider>().tag) == -1 && ExtraWhiteListtags.IndexOf(other.GetComponent<Collider>().tag) == -1)
            {
                if (other.tag == "Player")
                {
                    other.GetComponent<PlayerBehaviour>().takedamage(damage);
                }
                foreach (Statuses.StatusType s in StatusEffects)
                {
                    try
                    {
                        other.GetComponent<Statuses>().ApplyStatus(s, this.gameObject);
                    }
                    catch
                    { }
                }
                OnCollide(other);
                Destroy(this.gameObject);  //The array "whitelisttags" contains the tags that the weapon does not hit
            }
        }
        catch
        {
            print("ERROR: projectile collided but something went wrong");
            throw;
        }
    }

    protected virtual void OnCollide(Collider other) {}

    public virtual void Shoot(GameObject Projectile, GameObject Shooter, GameObject Target, int damage)
    {
        GameObject shotprojectile = Instantiate(Projectile, Shooter.transform.position + Shooter.transform.forward.normalized / 5f, Shooter.transform.rotation, Shooter.transform);
        Rigidbody projectilerb = shotprojectile.GetComponent<Rigidbody>();
        float ForceToShootWith;
        shotprojectile.GetComponent<GenericWeapon>().AddToWhiteList(Shooter.tag);
        try
        {
            shotprojectile.transform.rotation = Quaternion.LookRotation(Target.transform.position - Shooter.transform.position);
        }
        catch { }
        shotprojectile.transform.Rotate(new Vector3(90f, 0f, 0f));
        if (Shooter.tag == "Enemy")
        {
            ForceToShootWith = 30000f;
        }
        else
        {
            ForceToShootWith = 11000f;
        }
        shotprojectile.GetComponent<GenericWeapon>().damage = damage;
        shotprojectile.SetActive(true);
        if (Target != null)
        {
            projectilerb.AddForce((Target.gameObject.transform.position - Shooter.transform.position).normalized * ForceToShootWith);
        }
        else
        {
            projectilerb.AddForce(Shooter.transform.forward.normalized * ForceToShootWith);
        }
    }
    public override void RandomiseStats(GenericItem.Rarities rarity)
    {
        this.gameObject.GetComponent<GenericItem>().SetCategory(GenericItem.CategoryEnum.Projectile);
        if (rarity == GenericItem.Rarities.Common) 
		{
			_damage = Random.Range (11, 20);
            this.gameObject.GetComponent<GenericItem>().SetDetails(rarity + " " + this.gameObject.GetComponent<GenericItem>().category, "A common arrow");
		}
		if (rarity == GenericItem.Rarities.Rare) 
		{
			_damage = Random.Range (21, 30);
            this.gameObject.GetComponent<GenericItem>().SetDetails(rarity + " " + this.gameObject.GetComponent<GenericItem>().category, "A rare arrow");
		}
		if (rarity == GenericItem.Rarities.Epic) 
		{
			_damage = Random.Range (31, 60);
            this.gameObject.GetComponent<GenericItem>().SetDetails(rarity + " " + this.gameObject.GetComponent<GenericItem>().category, "An epic arrow!");
		}
		if (rarity == GenericItem.Rarities.Legendary) 
		{
			_damage = Random.Range (61, 100);
            this.gameObject.GetComponent<GenericItem>().SetDetails(rarity + " " + this.gameObject.GetComponent<GenericItem>().category, "A legendary arrow!!");
		}
    }
}
