﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealingItem : StackableItem {

    [SerializeField]
    protected int _HpHealAmount;
    public int HpHealAmount
    {
        get { return _HpHealAmount; }
    }

    [SerializeField]
    protected int _MpHealAmount;
    public int MpHealAmount
    {
        get { return _MpHealAmount; }
    }

    [SerializeField]
    private bool Percentage;

    protected virtual void Awake()
    {
		_category = CategoryEnum.HealingItem;
    }

}
