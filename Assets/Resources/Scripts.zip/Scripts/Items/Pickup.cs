﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pickup : MonoBehaviour {

    public GameObject item;

    protected float Lifetime;
    protected float TimeSinceInstantiated;
    protected float Cooldown;
    protected bool StartDecaying;

    public delegate void SendPosEvent(GameObject thispickup);
    public static event SendPosEvent Created;
    public static event SendPosEvent SendPos;

	protected virtual void Start()
	{
        RunCreated();
        try
        {
            item = Instantiate (item,new Vector3(0f,1000f,0f),Quaternion.identity);            
		}
		catch
		{
			print("ERROR in pickup: couldn't set item");
		}
        if (Lifetime == 0)
        {
            Lifetime = 60f;
        }
	}

	protected void Update()
	{
        SendPos(this.gameObject);
        if (!Pause.Paused)
		{
			this.gameObject.transform.Rotate (new Vector3 (0f, 1f, 0f));
            if (TimeSinceInstantiated > Lifetime && StartDecaying)
            {
                this.gameObject.AddComponent<FadeOut>().FadePeriod = 2.5f;
            }
            else
            {
                TimeSinceInstantiated += Time.deltaTime;
            }
		}

	}

    protected void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && TimeSinceInstantiated > Cooldown)
        {
            if (item != null)
            {
                if (!other.GetComponent<PlayerInventory>().isinvfull())
                {
                    Minimap.DestroyItemIcon(this.gameObject);
                    other.GetComponent<PlayerInventory>().additem(Instantiate(item));
                }
                else
                {
                    TempPopup.Show("Inventory is full. Couldn't pick up item!", Color.red);
                }
            }
            else
            {
                TempPopup.Show("Item not assigned!", Color.red);
            }
            Destroy(item);
            Destroy(this.gameObject);
        }

		if (other.CompareTag ("Ground"))
		{
            this.transform.position = new Vector3(transform.position.x, transform.position.y + 0.1f, transform.position.z);
			this.gameObject.GetComponent<Rigidbody> ().useGravity = false;
			this.gameObject.GetComponent<Rigidbody> ().velocity = Vector3.zero;
		}
    }

    protected void RunCreated()
    {
        Created(this.gameObject);
    }

    public void SetProperties(float lifetime, float cooldown)
    {
        Lifetime = lifetime;
        Cooldown = cooldown;
        StartDecaying = true;
    }
}
