﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenericWeapon : MonoBehaviour
{

    [SerializeField]
    protected int _damage;
    public int damage
    {
        get {return _damage; }
        set
        {
            try {_damage = value; }
            catch {print("ERROR in weapon: couldn't set damage"); }
        }
    }

    [SerializeField]
    protected static List<string> _whitelisttags = new List<string>() //list of tags that the weapon will not affect
    {
        {"Projectile"}
    };
    public static List<string> whitelisttags
    {
        get {return _whitelisttags; }
    }

    protected List<string> _ExtraWhiteListtags = new List<string>();
    public List<string> ExtraWhiteListtags
    {
        get {return _ExtraWhiteListtags; }
    }

    [SerializeField]
	protected List<Statuses.StatusType> _StatusEffects = new List<Statuses.StatusType>();
    public List<Statuses.StatusType> StatusEffects
    {
        get {return _StatusEffects; }
    }

    [SerializeField]
    protected float _AttSpeed;
    public float AttSpeed
    {
        get {return _AttSpeed; }
    }

    protected virtual void OnTriggerEnter(Collider other)
	{
		try
		{
			if (whitelisttags.IndexOf(other.GetComponent<Collider>().tag) == -1 && ExtraWhiteListtags.IndexOf(other.GetComponent<Collider>().tag) == -1)
			{
				if(other.tag == "Player")
				{
					other.GetComponent<PlayerBehaviour>().takedamage(damage);
				}
                foreach (Statuses.StatusType s in StatusEffects)
                {
                    try
                    {
                        other.GetComponent<Statuses>().ApplyStatus(s, this.gameObject);
                    }
                    catch
                    { }
                }
			}

		}
		catch
		{
          print("ERROR in weapon: error dealing damage.");  
		}
	}

    public bool WhiteListed(GameObject thing)
    {
        if(whitelisttags.Contains(thing.tag) || ExtraWhiteListtags.Contains(thing.tag))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void AddToWhiteList(string tag)
    {
        ExtraWhiteListtags.Add(tag);
    }

    public virtual void RandomiseStats(GenericItem.Rarities rarity)
    {}
}
