﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyBindings : MonoBehaviour 
{

    private static Dictionary<string, string> _KeyBindings = new Dictionary<string, string>();
    public static Dictionary<string, string> KeyBinds
    {
        get { return _KeyBindings; }
    }

    private static Dictionary<string, string> _RevKeyBindings = new Dictionary<string, string>();
    public static Dictionary<string, string> RevKeyBinds
    {
        get { return _RevKeyBindings; }
    }

    void Awake()
	{
		_KeyBindings.Add("Interact", "E");
        _KeyBindings.Add("Shoot", "Mouse0");
        _KeyBindings.Add("LockOn", "Mouse1");
        _KeyBindings.Add("Inventory", "I");
        _KeyBindings.Add("Pause", "esc");
        _KeyBindings.Add("CmdLine", "`");
        foreach (string s in KeyBinds.Keys)
        {
            _RevKeyBindings.Add(KeyBinds[s], s);
        }
    }

    public static bool KeyPressed(string Action)
    {
        try
        {
            return Input.GetKeyDown((KeyCode)System.Enum.Parse(typeof(KeyCode), KeyBinds[Action]));
        }
        catch { return false; }
    }

    public static void AddAction(string action)
    {
        try
        {
            _KeyBindings.Add(action, "");
            _RevKeyBindings = new Dictionary<string, string>();
            foreach (string s in KeyBinds.Keys)
            {
                _RevKeyBindings.Add(KeyBinds[s], s);
            }
        }
        catch
        {
            print(action + " could not be addded to the key bindings");
        }
    }

    public static bool IsKeyBound(string key)
    {
        foreach (string s in KeyBinds.Values)
        {
            if (s == key.ToUpper() || s == key)
            {
                return true;
            }
        }
        return false;
    }

}
