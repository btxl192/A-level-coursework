﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MinimapToggle : MonoBehaviour {

    public GameObject minimap;

	void Start ()
    {
        this.GetComponentInChildren<Text>().text = "Minimap: " + minimap.activeSelf;
        this.GetComponent<Button>().onClick.AddListener(ToggleMinimap);
	}

    void ToggleMinimap()
    {
        minimap.SetActive(!minimap.activeSelf);
        this.GetComponentInChildren<Text>().text = "Minimap: " + minimap.activeSelf;
    }
}
