﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MinimapZoom : MonoBehaviour {

    public Minimap minimap;

    private int ZoomLevel;
    private int[] ZoomLevels = { 1, 2, 3, 4, 5 };
	void Start ()
    {
        ZoomLevel = (int)(minimap.GetZoom() / 2);
        this.gameObject.GetComponent<Button>().onClick.AddListener(ChangeZoomLevel);
        this.gameObject.GetComponentInChildren<Text>().text = "Zoom Level: " + minimap.GetZoom();
	}

    void ChangeZoomLevel()
    {
        ZoomLevel = ZoomLevels[(ZoomLevel) % ZoomLevels.Length];
        minimap.SetZoom(ZoomLevel * 2);
        this.gameObject.GetComponentInChildren<Text>().text = "Zoom Level: " + minimap.GetZoom();
    }
}
