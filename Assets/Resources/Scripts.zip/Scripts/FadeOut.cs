﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FadeOut : MonoBehaviour {

	public float FadePeriod;
	private Material thismaterial;

	void Awake () 
	{
		thismaterial = this.gameObject.GetComponent<Renderer>().material;
	}
	
	void Update () 
	{
		thismaterial.color = new Color(thismaterial.color.r,thismaterial.color.g,thismaterial.color.b,thismaterial.color.a-(1/FadePeriod)*Time.deltaTime);
		if(thismaterial.color.a<=0)
		{
			Destroy(this.gameObject);
		}
	}
}
