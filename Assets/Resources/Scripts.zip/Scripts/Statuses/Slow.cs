﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Slow : StatusBase
{
    protected override float lifetime { get { return 5; } }
    private float defaultspeed;

    protected override void OnStatusApplied()
    {
        if (this.gameObject.GetComponent<GenericEnemy>() != null)
        {
            defaultspeed = this.gameObject.GetComponent<UnityEngine.AI.NavMeshAgent>().speed;
            this.gameObject.GetComponent<UnityEngine.AI.NavMeshAgent>().speed = defaultspeed * (1f / ((float)Level + 1f));
        }
        if (this.gameObject.GetComponent<PlayerBehaviour>() != null)
        {
            defaultspeed = this.gameObject.GetComponent<PlayerMovement>().speed;
            this.gameObject.GetComponent<PlayerMovement>().speed = defaultspeed * (1f / ((float)Level + 1f));
        }
    }

    protected override void OnStatusEnd()
    {
        if (this.gameObject.GetComponent<GenericEnemy>() != null)
        {
            this.gameObject.GetComponent<UnityEngine.AI.NavMeshAgent>().speed = defaultspeed;
        }
        if (this.gameObject.GetComponent<PlayerBehaviour>() != null)
        {
            this.gameObject.GetComponent<PlayerMovement>().speed = defaultspeed;
        }
    }

}
