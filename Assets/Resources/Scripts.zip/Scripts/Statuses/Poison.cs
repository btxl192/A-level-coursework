﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Poison : StatusBase {

    public int damage;
    private float lastUpdate;
    protected override float lifetime{get {return 10; }}

    protected override void Update ()
    {
        base.Update();
        //https://answers.unity.com/questions/134474/add-to-score-every-second.html
        if (Time.time - lastUpdate >= 1f)
        {
            CauseDamage();
            lastUpdate = Time.time;
        }
    }

    void CauseDamage()
    {
        if (this.gameObject.GetComponent<PlayerStats>() != null)
        {
            this.GetComponent<PlayerStats>().HP.ChangeHealth(-(int)(damage * (0.25f + 0.2 * (Level - 1))));
        }
        if (this.gameObject.GetComponent<GenericEnemy>() != null)
        {
            int toxiclv = SkillManager.Skills[0].Level;
            this.GetComponent<GenericEnemy>().TakeDamage((int)(damage * (0.5f + 0.2 * (Level - 1 + toxiclv))));
        }
    }
}
