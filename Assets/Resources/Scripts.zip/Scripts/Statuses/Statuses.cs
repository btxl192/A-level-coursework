﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Statuses : MonoBehaviour {

	private GameObject target;
	public enum statuses {Poison, Slow};
    public struct StatusType
    {
        public statuses Type;
        public int Level;
    }

    [SerializeField]
	private List<StatusBase> CurrentStatuses = new List<StatusBase> ();

    void Awake()
    {
        StatusBase.StatusApplied += AddStatus;
        StatusBase.EndStatus += RemoveStatus;
        target = this.gameObject;
    }

    void AddStatus(StatusBase s)
    {
        CurrentStatuses.Add(s);
    }

    void RemoveStatus(StatusBase s)
    {
        CurrentStatuses.Remove(s);
    }

    public void ApplyStatus(StatusType StatusType, object param)
    {
        if (StatusType.Type == statuses.Poison)
        {
            target.AddComponent<Poison>().SetLevel(StatusType.Level);
            try
            {
                target.GetComponent<Poison>().damage = (int)param;
            }
            catch
            {
                if (((GameObject)param).GetComponent<GenericWeapon>() != null)
                {
                    target.GetComponent<Poison>().damage = ((GameObject)param).GetComponent<GenericWeapon>().damage;
                }
                if (((GameObject)param).GetComponent<GenericEnemy>() != null)
                {
                    target.GetComponent<Poison>().damage = ((GameObject)param).GetComponent<GenericEnemy>().damage;
                }
            }
        }
        if (StatusType.Type == statuses.Slow)
        {
            target.AddComponent<Slow>().SetLevel(StatusType.Level);
        }
    }

    public static StatusType MakeStatus(statuses Type, int Level)
    {
        StatusType temp;
        temp.Type = Type;
        temp.Level = Level;
        return temp;
    }

}
