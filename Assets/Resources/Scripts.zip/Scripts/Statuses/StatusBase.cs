﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class StatusBase : MonoBehaviour {

    private float timelived = 0;
    protected abstract float lifetime { get; }
    protected int Level;

    public delegate void StatusEvent(StatusBase s);
    public static event StatusEvent EndStatus;
    public static event StatusEvent StatusApplied;

    protected void Start()
    {
        StatusApplied(this);
        OnStatusApplied();
    }

    protected virtual void Update ()
    {
        timelived += Time.deltaTime;
        if (timelived >= lifetime)
        {
            EndStatus(this);
            OnStatusEnd();
            Destroy(this);
        }
	}

    public void SetLevel(int i)
    {
        Level = i;
    }

    protected virtual void OnStatusApplied() { }
    protected virtual void OnStatusEnd() { }
}
