﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SellButton : MonoBehaviour {

    public delegate void MerchantMode(MerchantUI.Mode m);
    public static event MerchantMode SwitchSell;

    void Awake ()
    {
        this.GetComponent<Button>().onClick.AddListener(SwitchToSell);
        MerchantUI.DeselectButtons += Deselected;
    }

    void SwitchToSell()
    {
        SwitchSell(MerchantUI.Mode.Sell);
        Selected();
    }

    void Selected()
    {
        this.GetComponent<Image>().color = Color.yellow;
    }

    void Deselected()
    {
        this.GetComponent<Image>().color = Color.white;
    }
}
