﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BuyBackButton : MonoBehaviour {

    public delegate void MerchantMode(MerchantUI.Mode m);
    public static event MerchantMode SwitchBuyBack;

    void Awake()
    {
        this.GetComponent<Button>().onClick.AddListener(SwitchToBuyBack);
        MerchantUI.DeselectButtons += Deselected;
    }

    void SwitchToBuyBack()
    {
        SwitchBuyBack(MerchantUI.Mode.BuyBack);
        Selected();
    }

    void Selected()
    {
        this.GetComponent<Image>().color = Color.yellow;
    }

    void Deselected()
    {
        this.GetComponent<Image>().color = Color.white;
    }
}
