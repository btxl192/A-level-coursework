﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BuyButton : MonoBehaviour {

    public delegate void MerchantMode(MerchantUI.Mode m);
    public static event MerchantMode SwitchBuy;

	void Awake () 
	{
        this.GetComponent<Button>().onClick.AddListener(SwitchToBuy);
        MerchantUI.DeselectButtons += Deselected;
        MerchantUI.SetBuyYellow += Selected;
	}

    void SwitchToBuy()
    {
        SwitchBuy(MerchantUI.Mode.Buy);
        Selected();
    }

    void Selected()
    {
        this.GetComponent<Image>().color = Color.yellow;
    }

    void Deselected()
    {
        this.GetComponent<Image>().color = Color.white;
    }
}
