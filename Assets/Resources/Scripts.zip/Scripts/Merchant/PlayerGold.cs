﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerGold : MonoBehaviour {

	void Update () 
	{
		this.gameObject.GetComponent<UnityEngine.UI.Text>().text = "Gold: " + GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerInventory>().Gold.ToString();
	}
}
