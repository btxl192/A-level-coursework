﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemButton : MonoBehaviour {

	public delegate void ItemEvent(int merchantid, int itemindex);
	public static event ItemEvent SellItem;
    public static event ItemEvent BuyItem;

    public delegate void UpdateUIEvent(int merchantid);
    public static event UpdateUIEvent UpdateBuy;
    public static event UpdateUIEvent UpdateSell;

    private Ware ware;
    private PlayerInventory Player;

    public int SlotIndex {get; set;}

	public int MerchantID {get; private set;}

    void Awake () 
	{
        Player = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerInventory>();
        this.gameObject.GetComponent<Button>().onClick.AddListener (ButtonClicked);
		ware = MerchantList.Merchants [MerchantID].Wares [SlotIndex];
        UpdateHoverText();
	}

    void ButtonClicked()
    {
        switch (MerchantUI.CurrentMode)
        {
            case MerchantUI.Mode.Buy:
            case MerchantUI.Mode.BuyBack:
                SellItem(MerchantID, SlotIndex);
                UpdateBuy(MerchantID);
                break;
            case MerchantUI.Mode.Sell:
                BuyItem(MerchantID, SlotIndex);
                UpdateSell(MerchantID);
                break;
            default:
                print("MERCHANT BUTTON NOT WORKING");
                break;
        }
    }

	public void UpdateSlot(int merchantid, MerchantUI.Mode m)
	{
		MerchantID = merchantid;
        if (m == MerchantUI.Mode.Buy)
        {
            ware = MerchantList.Merchants[MerchantID].Wares[SlotIndex];
        }
        else if (m == MerchantUI.Mode.Sell)
        {
            int amount;
            if (Player.inventory[SlotIndex].GetComponent<StackableItem>())
            {
                amount = Player.inventory[SlotIndex].GetComponent<StackableItem>().Amount;
            }
            else
            {
                amount = 1;
            }
            ware = new Ware(Player.inventory[SlotIndex], amount, true);
        }
        else if (m == MerchantUI.Mode.BuyBack)
        {
            ware = MerchantList.Merchants[MerchantID].BuyBack[SlotIndex];
        }
        this.gameObject.GetComponentInChildren<Text>().text = ware.Item.itemname + " (" + ware.Price + " gold)";
        if (ware.Quantity == -1)
        {
            this.gameObject.GetComponentsInChildren<Text>()[1].text = "Stock: Unlimited";
        }
        else
        {
            this.gameObject.GetComponentsInChildren<Text>()[1].text = "Stock: " + ware.Quantity;
        }      
        UpdateHoverText();
	}

    void UpdateHoverText()
    {
        this.GetComponent<HoverText>().Text = ware.Item.itemname + "\n" + ware.Item.desc;
        if (ware.Item.category == GenericItem.CategoryEnum.Weapon)
        {
            this.GetComponent<HoverText>().Text += "\nDamage: " + ware.ItemObject.GetComponent<GenericWeapon>().damage;
        }
    }
}
