﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MerchantUI : MonoBehaviour {

    public enum Mode {Buy, Sell, BuyBack}

	private int MerchantID;
    public static Mode CurrentMode
    {
        get;
        private set;
    }
	private static bool _CurrentlyOpen;
	public static bool CurrentlyOpen
	{
		get {return _CurrentlyOpen; }
	}

    public delegate void UpdateItems(int ID);
    public static event UpdateItems UpdateBuy;
    public static event UpdateItems UpdateSell;

    public delegate void BlankEvent();
    public static event BlankEvent DeselectButtons;
    public static event BlankEvent SetBuyYellow;

    public void Awake()
	{
		Merchant.OpenTradeMenu += OpenMenu;
		Merchant.CloseTradeMenu += CloseMenu;
        BuyButton.SwitchBuy += SwitchMode;
        SellButton.SwitchSell += SwitchMode;
        BuyBackButton.SwitchBuyBack += SwitchMode;
		this.gameObject.GetComponent<Canvas>().enabled = false;
	}

    public void Start()
    {
        SetBuyYellow();
    }

    public void OpenMenu(int merchantid)
	{
		_CurrentlyOpen = true;
		MerchantID = merchantid;
		this.gameObject.GetComponent<Canvas>().enabled = true;
        UpdateBuy(MerchantID);
        GenericMenu2.SetOpenMenu(this.gameObject);
	}

	public void CloseMenu(int merchantid)
	{
		this.gameObject.GetComponent<Canvas>().enabled = false;
		_CurrentlyOpen = false;
        GenericMenu2.SetOpenMenu(null);
    }

	public void UpdateSlots(Mode m)
	{
		foreach(ItemButton i in this.GetComponentsInChildren<ItemButton>())
		{
            i.UpdateSlot(MerchantID, m);
		}
	}

    void SwitchMode(Mode m)
    {
        DeselectButtons();
        CurrentMode = m;
        if (m == Mode.Buy || m == Mode.BuyBack)
        {
            UpdateBuy(MerchantID);
        }
        else if (m == Mode.Sell)
        {
            UpdateSell(MerchantID);
        }
    }
}
