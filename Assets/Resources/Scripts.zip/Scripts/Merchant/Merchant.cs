﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Merchant : Interactable {

    public enum Presets { PotionSeller, TestPreset};

    public Presets Preset;

    [SerializeField]
	private List<Ware> _Wares = new List<Ware>();
	public List<Ware> Wares
	{
		get {return _Wares;}
	}

	[SerializeField]
	private static List<Ware> _BuyBack = new List<Ware>();
	public List<Ware> BuyBack
	{
		get {return _BuyBack;}
	}

    private PlayerInventory PlayerInv;
	public delegate void MerchantEvent(int merchantid);
	public static event MerchantEvent OpenTradeMenu;
	public static event MerchantEvent CloseTradeMenu;

    [SerializeField]
	public int MerchantID
	{
		get;
		private set;
	}

	protected override void Awake () 
	{
		PopupText = "Trade";
		base.Awake();
		MerchantList.Merchants.Add(this.gameObject.GetComponent<Merchant>());
		MerchantID = MerchantList.Merchants.IndexOf(this);
		ItemButton.SellItem += SellWare;
        ItemButton.BuyItem += BuyFromPlayer;
        LoadWares(Preset);
        PlayerInv = Player.GetComponent<PlayerInventory>();
    }

    protected override void Interact()
	{
		if(!MerchantUI.CurrentlyOpen)
		{
			OpenTradeMenu(MerchantID);
		}
		else if(MerchantUI.CurrentlyOpen)
		{
			Interacting = false;
			CloseTradeMenu(MerchantID);
		}		
	}

	protected override void OutOfRange()
	{
		CloseTradeMenu(MerchantID);
	}

	void SellWare(int merchantid, int WareIndex)
	{
        List<Ware> temp;
        if (MerchantUI.CurrentMode == MerchantUI.Mode.Buy)
        {
            temp = Wares;
        }
        else if (MerchantUI.CurrentMode == MerchantUI.Mode.BuyBack)
        {
            temp = BuyBack;
        }
        else
        {
            temp = null;
        }
        if (PlayerInv.Gold >= temp[WareIndex].Price && merchantid == MerchantID)
        {
            if (!PlayerInv.isinvfull())
            {
                PlayerInv.Gold -= temp[WareIndex].Price;
                PlayerInv.additem(Instantiate(temp[WareIndex].ItemObject));
                if (temp[WareIndex].Quantity != -1)
                {
                    temp[WareIndex].ChangeQuantity(-1);
                    if (temp[WareIndex].Quantity <= 0)
                    {
                        temp.RemoveAt(WareIndex);
                    }
                }
            }
            else
            {
                TempPopup.Show("Inventory is full! Couldn't purchase item.", Color.red);
            }
        }
        else
        {
            TempPopup.Show("Not enough gold to purchase!", Color.red);
        }
	}

    void BuyFromPlayer(int merchantid, int PlayerInvIndex)
    {
        if (merchantid == MerchantID)
        {
            PlayerInv.Gold += GetPrice(PlayerInv.inventory[PlayerInvIndex], true);           
            if (PlayerInv.inventory[PlayerInvIndex].GetComponent<StackableItem>() != null)
            {
                GameObject temp = Instantiate(PlayerInv.inventory[PlayerInvIndex]);
                bool exists = false;
                temp.GetComponent<StackableItem>().SetAmount(1);
                foreach (Ware w in BuyBack)
                {
                    if (w.ItemObject.GetComponent<GenericItem>().itemname == temp.GetComponent<GenericItem>().itemname)
                    {
                        exists = true;
                        w.ChangeQuantity(1);
                    }
                }
                if (!exists)
                {
                    BuyBack.Add(new Ware(temp, 1, true));
                }               
                PlayerInv.inventory[PlayerInvIndex].GetComponent<StackableItem>().ChangeAmount(-1);
            }
            else
            {
                BuyBack.Add(new Ware(PlayerInv.inventory[PlayerInvIndex], 1, true));
                PlayerInv.inventory.RemoveAt(PlayerInvIndex);
            }
            
        }
    }

    public void LoadWares(Presets MerchantPreset)
    {
        if (MerchantPreset == Presets.PotionSeller)
        {
            _Wares = new List<Ware>
            { 
            };
        }
        if (MerchantPreset == Presets.TestPreset)
        {
            _Wares = new List<Ware>
            {
                new Ware(Resources.Load(FileDir.HealingPotion) as GameObject,-1,false),
                new Ware(Resources.Load(FileDir.GreaterHealingPotion) as GameObject, 10, false)
            };
        }
    }

	public static int GetPrice(GameObject item, bool PlayerPrice)
    {
        if (PlayerPrice)
        {
            return (int)(item.GetComponent<GenericItem>().Price * 0.5f);
        }
        else
        {
            return item.GetComponent<GenericItem>().Price;
        }
    }

}
