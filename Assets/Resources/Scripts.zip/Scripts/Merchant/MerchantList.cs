﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MerchantList : MonoBehaviour {

	public static List<Merchant> Merchants = new List<Merchant>();

}
