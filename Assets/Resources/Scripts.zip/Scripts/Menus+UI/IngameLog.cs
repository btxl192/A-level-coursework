﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IngameLog : MonoBehaviour {

	public static Transform ThisLog;

	public void Awake()
	{
		ThisLog = GameObject.FindGameObjectWithTag("Log").transform;
	}

	public static void Log(string message, Color messageColour)
	{
        GameObject temp = FadingText.InstFadingText(2.5f, ThisLog.gameObject);
        temp.GetComponent<UnityEngine.UI.Text>().text = message;
		temp.GetComponent<UnityEngine.UI.Text>().color = messageColour;
	}
}
