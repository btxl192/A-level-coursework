﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisableUIChildren : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
		GenericMenu2.OnOpen += Enable;
		GenericMenu2.OnClose += Disable;
	}
	
	void Enable()
	{
		for (int a = 1; a < this.GetComponentsInChildren<RectTransform>(true).Length; a++)
		{
            this.GetComponentsInChildren<RectTransform>(true)[a].gameObject.SetActive(true);
		}
	}

	void Disable()
	{
		for (int a = 1; a < this.GetComponentsInChildren<RectTransform>(true).Length; a++)
		{
			this.GetComponentsInChildren<RectTransform>(true)[a].gameObject.SetActive(false);
		}
	}

	void Switch()
	{
		for (int a = 1; a < this.GetComponentsInChildren<RectTransform>(true).Length; a++)
		{
			this.GetComponentsInChildren<RectTransform>(true)[a].gameObject.SetActive(!this.GetComponentsInChildren<RectTransform>(true)[a].gameObject.activeSelf);
		}
	}
}
