﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class GenericMenu : MonoBehaviour {

    [SerializeField]
    protected string TypeOfMenu;

	protected float height;
	[SerializeField]
	protected float width;
	protected float _actualheight;
	public float actualheight
	{
		get {return _actualheight; }
	}
	protected float _actualwidth;
	public float actualwidth
	{
		get {return _actualwidth; }
	}

	protected Transform bg;
    public static GameObject OpenMenu { get; protected set; }

    public delegate void pause();
    public static event pause pauser;
    public static event pause unpauser;
	public delegate void OpenOrCloseEvent();
	public static event OpenOrCloseEvent OnOpen;
    public static event OpenOrCloseEvent OnClose;
	
	protected virtual void Start () 
    {
        this.gameObject.GetComponent<Canvas>().enabled = false; 
		bg = this.gameObject.transform.Find("bg");
		height = width * (0.5625f);
		_actualwidth = width * Screen.width;
		_actualheight = height * Screen.width;
	}
	
	protected void Update () 
    {
		if ((Input.inputString.ToUpper () == KeyBindings.KeyBinds[TypeOfMenu].ToUpper () && this.gameObject.GetComponent<Canvas> ().enabled == false && OpenMenu == null && GenericMenu2.OpenMenu == null) )
		{//if the key is pressed and the menu is closed, open the menu and pause the game
            AdditionalBehaviourOnOpen();
            OpenMenu = this.gameObject;
			_actualwidth = width * Screen.width;
			_actualheight = height * Screen.width;
			if (bg != null) {
				bg.gameObject.GetComponent<RectTransform> ().sizeDelta = new Vector2 (_actualwidth, _actualheight);
			}
            try
            {
                RunOnOpen();
            }
            catch
            {
                print(this.gameObject + ": generic menu. No event handler for OnOpen()");
            }
			this.gameObject.GetComponent<Canvas> ().enabled = true;
			RunPauser ();
		} 
		else if (Input.inputString.ToUpper () == KeyBindings.KeyBinds[TypeOfMenu].ToUpper () && this.gameObject.GetComponent<Canvas> ().enabled == true)  {//if the key is pressed and the menu is open, close the menu and resume the game
			OpenMenu = null;
            AdditionalBehaviourOnClose();
            try
            {
                RunOnClose();
            }
            catch
            {
                print(this.gameObject + ": generic menu. No event handler for OnClose()");
            }
            this.gameObject.GetComponent<Canvas> ().enabled = false;
			RunUnpauser ();
		} 
	}

    protected virtual void AdditionalBehaviourOnOpen()
    { }

    protected virtual void AdditionalBehaviourOnClose()
    { }

    protected void RunPauser()
	{
		pauser();
	}

	protected void RunUnpauser()
	{
		unpauser();
	}

	protected void RunOnOpen()
	{
		OnOpen ();
	}

    protected void RunOnClose()
    {
        OnClose();
    }
}
