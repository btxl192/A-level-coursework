﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuButton : GenericMenuPart {

	public Canvas ToOpen;
	public float position;

	public float widthmult;
	public float heightmult;

	private GameObject bg;
	private Canvas[] siblings;

	public override float width
	{
		get
		{
			return bgwidth * widthmult;
		}
	}

	public override float height
	{
		get
		{
			return bgheight * heightmult;
		}
	}

	protected override void Start () 
	{
		base.Start ();
		if(this.gameObject.GetComponent<Button>() != null)
		{
			this.gameObject.GetComponent<Button>().onClick.AddListener (OpenMenu);
		}
		bg = this.gameObject.transform.parent.gameObject;
		siblings = bg.GetComponentsInChildren<Canvas> ();
	}

	protected override void UpdateDimensions()
	{
		base.UpdateDimensions();
		this.GetComponent<RectTransform> ().anchoredPosition = new Vector3 (5f, height * position, 0f);
	}

	void OpenMenu()
	{
		foreach (Canvas item in siblings)
		{
			item.enabled = false;
		}
		ToOpen.enabled = true;
	}
}
