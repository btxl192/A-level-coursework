﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GenericMenu2 : MonoBehaviour {

    [SerializeField]
    protected string TypeOfMenu;

	public static GameObject OpenMenu { get; protected set; }

	public delegate void BlankEvent();
	public static event BlankEvent pauser;
	public static event BlankEvent unpauser;
	public static event BlankEvent OnOpen;
	public static event BlankEvent OnClose;

	protected virtual void Start () 
	{
		this.gameObject.GetComponent<Canvas>().enabled = false; 
	}

	protected virtual void Update () 
	{
		if (((Input.inputString.ToUpper () == KeyBindings.KeyBinds[TypeOfMenu].ToUpper () || (Input.GetKeyDown (KeyCode.Escape) && KeyBindings.KeyBinds[TypeOfMenu].ToUpper () == "ESC")) && this.gameObject.GetComponent<Canvas> ().enabled == false && OpenMenu == null && GenericMenu.OpenMenu == null)) //if the key is pressed and the menu is closed, open the menu and pause the game
        {
			OpenMenu = this.gameObject;
			this.gameObject.GetComponent<Canvas> ().enabled = true;
			RunPauser ();
			try
			{
				OnOpen();				
			}
			catch{
			}
		} 
		else if ((Input.inputString.ToUpper () == KeyBindings.KeyBinds[TypeOfMenu].ToUpper () || (Input.GetKeyDown (KeyCode.Escape) && KeyBindings.KeyBinds[TypeOfMenu].ToUpper () == "ESC") && this.gameObject.GetComponent<Canvas> ().enabled == true) ) //if the key is pressed and the menu is open, close the menu and resume the game
        { 
            OpenMenu = null;
			this.gameObject.GetComponent<Canvas> ().enabled = false;
			RunUnpauser ();
			try
			{
				OnClose();				
			}
			catch{
			}
		} 
	}

	protected void RunPauser()
	{
		pauser();
	}

	protected void RunUnpauser()
	{
		unpauser();
	}

    public static void SetOpenMenu(GameObject Menu)
    {
        OpenMenu = Menu;
    }
}
