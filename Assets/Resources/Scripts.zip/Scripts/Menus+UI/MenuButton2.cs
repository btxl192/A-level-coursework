﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuButton2 : MonoBehaviour {

	public Canvas ToOpen;

	private GameObject bg;
	private Canvas[] siblings;

	void Start () 
	{
		if(this.gameObject.GetComponent<Button>() != null)
		{
			this.gameObject.GetComponent<Button>().onClick.AddListener (OpenMenu);
		}
		bg = this.gameObject.transform.parent.gameObject;
		siblings = bg.GetComponentsInChildren<Canvas> ();
	}

	void OpenMenu()
	{		
		foreach (Canvas item in siblings)
		{
			if (item != this.gameObject.GetComponentInParent<Canvas>()) 
			{
				item.enabled = false;
			}
		}
        foreach (Transform child in transform.parent)
        {
            if (child.GetComponent<Button>() != null && child.gameObject != this.gameObject)
            {
                child.gameObject.SetActive(false);
            }
        }
		ToOpen.enabled = true;
        this.gameObject.SetActive(false);
    }


}
