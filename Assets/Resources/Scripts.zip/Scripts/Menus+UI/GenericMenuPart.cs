﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public abstract class GenericMenuPart : MonoBehaviour {

	public float bgheight;
	public float bgwidth;

	public abstract float width
	{
		get;
	}
        
	public abstract float height
	{
		get;
	}

	protected virtual void Start () 
	{
		GenericMenu.OnOpen += UpdateDimensions;
        Inventory.OnOpen += Enable;
        Inventory.OnClose += Disable;
	}

	protected virtual void UpdateDimensions()
	{
		try
		{
			bgheight = this.gameObject.GetComponentInParent<GenericMenu> ().actualheight;
			bgwidth = this.gameObject.GetComponentInParent<GenericMenu> ().actualwidth;
		}
		catch 
		{
			print ("no GenericMenu as a parent");
		}
		this.gameObject.GetComponent<RectTransform> ().sizeDelta = new Vector2 (width, height);
	}

    protected void Enable()
    {
        try
        {
            this.gameObject.GetComponent<Image>().raycastTarget = true;
            this.gameObject.GetComponent<Button>().interactable = true;
            this.gameObject.GetComponentInChildren<Text>().raycastTarget = true;
        }
        catch
        {
            Inventory.OnOpen -= Enable;
        }
    }

    protected void Disable()
    {
        try
        {
            this.gameObject.GetComponent<Image>().raycastTarget = false;
            this.gameObject.GetComponent<Button>().interactable = false;
            this.gameObject.GetComponentInChildren<Text>().raycastTarget = false;
        }
        catch
        {
            print(this.gameObject + "couldn't be disabled");
            Inventory.OnClose -= Disable;
        }
    }
}
