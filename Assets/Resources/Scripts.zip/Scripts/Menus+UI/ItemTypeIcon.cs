﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemTypeIcon : MonoBehaviour {

    float size;

    public void ChangeItemType(string category)
    {
        switch (category)
        {
            case "Armour":
                this.gameObject.GetComponent<UnityEngine.UI.Image>().sprite = Resources.Load<Sprite>(FileDir.ArmourIcon);
                break;
            case "Projectile":
                this.gameObject.GetComponent<UnityEngine.UI.Image>().sprite = Resources.Load<Sprite>(FileDir.ProjectileIcon);
                break;
            case "Healing Item":
                this.gameObject.GetComponent<UnityEngine.UI.Image>().sprite = Resources.Load<Sprite>(FileDir.HealingItemIcon);
                break;
            default:
                this.gameObject.GetComponent<UnityEngine.UI.Image>().sprite = Resources.Load<Sprite>(FileDir.BlankIcon);
                break;
        }
    }
}
