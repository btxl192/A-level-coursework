﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuPartLoc : MonoBehaviour {

	public float bgheight;
	public float bgwidth;
	public float height;
	public float width;
	public float locX;
	public float locY;

	protected virtual void Start () 
	{
		GenericMenu.OnOpen += UpdateSize;
		UpdateSize ();
	}

	void UpdateSize()
	{
		try
		{
			bgheight = this.gameObject.GetComponentInParent<GenericMenu> ().actualheight;
			bgwidth = this.gameObject.GetComponentInParent<GenericMenu> ().actualwidth;
		}
		catch
		{
			print("ERROR in " + this.gameObject + ": no GenericMenu attached");
		}
		this.gameObject.GetComponent<RectTransform> ().sizeDelta = new Vector2 (width * bgwidth, height * bgheight);
		this.gameObject.GetComponent<RectTransform> ().anchoredPosition = new Vector3 (locX * bgwidth, locY * bgheight, 0f);
	}
}
