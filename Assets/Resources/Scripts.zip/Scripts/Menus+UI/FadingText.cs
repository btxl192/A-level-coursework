﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FadingText : MonoBehaviour {

	private float FadePeriod;
    private GameObject Parent;
    private bool SetupDone;

	public delegate void InstantiatedEvent(GameObject parent);
	public static event InstantiatedEvent Instantiated;

    void Update () 
	{
        if (SetupDone)
        {
            this.gameObject.GetComponent<Text>().color = new Color(this.gameObject.GetComponent<Text>().color.r, this.gameObject.GetComponent<Text>().color.g, this.gameObject.GetComponent<Text>().color.b, this.gameObject.GetComponent<Text>().color.a - (1 / FadePeriod) * Time.unscaledDeltaTime);
            if (this.gameObject.GetComponent<Text>().color.a <= 0)
            {
                Instantiated -= Move;
                Destroy(this.gameObject);
            }
        }
	}

	void Move(GameObject parent)
	{
        if (parent == Parent)
        {
            this.gameObject.GetComponent<RectTransform>().position = new Vector3(this.gameObject.GetComponent<RectTransform>().position.x, this.gameObject.GetComponent<RectTransform>().position.y + this.gameObject.GetComponent<RectTransform>().sizeDelta.y, this.gameObject.GetComponent<RectTransform>().position.z);
        }
    }

    void Setup(float fadePeriod, GameObject parent)
    {
        Parent = parent;
        FadePeriod = fadePeriod;
        this.gameObject.GetComponent<RectTransform>().position = new Vector3(this.gameObject.GetComponent<RectTransform>().position.x, this.gameObject.GetComponent<RectTransform>().position.y - this.gameObject.GetComponent<RectTransform>().sizeDelta.y, this.gameObject.GetComponent<RectTransform>().position.z);
        Instantiated += Move;
        Instantiated(Parent);
        SetupDone = true;
    }

    public static GameObject InstFadingText(float fadePeriod, GameObject parent)
    {
        GameObject temp = Instantiate(Resources.Load(FileDir.FadingText) as GameObject, parent.transform);
        temp.GetComponent<FadingText>().Setup(fadePeriod, parent);
        return temp;
    }

    public static GameObject InstFadingTextMid(float fadePeriod, GameObject parent)
    {
        GameObject temp = Instantiate(Resources.Load(FileDir.FadingTextMid) as GameObject, parent.transform);
        temp.GetComponent<FadingText>().Setup(fadePeriod, parent);
        return temp;
    }
}
