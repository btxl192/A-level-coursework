﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TempPopup : MonoBehaviour {

    public static Transform ThisPopup;

    public void Awake()
    {
        ThisPopup = GameObject.FindGameObjectWithTag("TempPopup").transform;
    }

    public static void Show(string message, Color messageColour)
    {
        GameObject temp = FadingText.InstFadingTextMid(2f, ThisPopup.gameObject);
        temp.GetComponent<UnityEngine.UI.Text>().text = message;
        temp.GetComponent<UnityEngine.UI.Text>().color = messageColour;
        temp.GetComponent<UnityEngine.UI.Text>().fontSize = 16;
        temp.GetComponent<RectTransform>().sizeDelta = new Vector2(ThisPopup.GetComponent<RectTransform>().sizeDelta.x, ThisPopup.GetComponent<RectTransform>().sizeDelta.y);
    }
}
