﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HoverText : MonoBehaviour {

	private GameObject bg;
    [SerializeField]
	private bool MouseHovering;
	private GameObject hovertext;

	public string ParentTag;
	public string Text;

	void Start () 
	{
		bg = Instantiate(Resources.Load(FileDir.BlueBG) as GameObject, GameObject.FindGameObjectWithTag(ParentTag).transform);
		bg.GetComponent<RectTransform>().anchorMax = new Vector2(0.5f,0.5f);
		bg.GetComponent<RectTransform>().anchorMin = new Vector2(0.5f,0.5f);
		bg.GetComponent<RectTransform>().pivot = new Vector2(0f,0.5f);
		//bg.GetComponent<RectTransform>().sizeDelta = new Vector2(bg.GetComponent<RectTransform>().sizeDelta.x, Screen.width*0.2f);
		hovertext = Instantiate(Resources.Load(FileDir.Text) as GameObject, bg.transform);
		//hovertext.GetComponent<RectTransform>().sizeDelta = bg.GetComponent<RectTransform>().sizeDelta;
		hovertext.GetComponent<RectTransform>().anchoredPosition = new Vector3(5f,0f,0f);
		hovertext.GetComponent<Text>().color = Color.white;
		hovertext.GetComponent<Text> ().text = Text;
        SetSize();
	}
	
	void Update()
	{
		if(MouseHovering)
		{
			bg.SetActive(true);
            bg.GetComponent<RectTransform>().position = Input.mousePosition;
		}
		else
		{
			bg.SetActive(false);
		}
	}

	public void MouseOver()
	{
		MouseHovering = true;
        SetSize();
	}

	public void MouseExit()
	{
		MouseHovering = false;
	}

	public void ChangeText(string Textt)
	{
		hovertext.GetComponent<Text> ().text = Textt;
        
        SetSize();
	}

    void OnDestroy()
    {
        Destroy(bg);
    }

    void SetSize()
    {
        //print(hovertext.GetComponent<RectTransform>().)
        print(LayoutUtility.GetPreferredHeight(hovertext.GetComponent<Text>().GetComponent<RectTransform>()));
        if (LayoutUtility.GetPreferredWidth(hovertext.GetComponent<Text>().rectTransform) > Screen.width * 0.3f)
        {
            bg.GetComponent<RectTransform>().sizeDelta = new Vector2(Screen.width * 0.3f + 6f, LayoutUtility.GetPreferredHeight(hovertext.GetComponent<Text>().rectTransform));
        }
        else
        {
            bg.GetComponent<RectTransform>().sizeDelta = new Vector2(LayoutUtility.GetPreferredWidth(hovertext.GetComponent<Text>().GetComponent<RectTransform>()) + 6f, LayoutUtility.GetPreferredHeight(hovertext.GetComponent<Text>().rectTransform));
        }
        //hovertext.GetComponent<RectTransform>().sizeDelta = bg.GetComponent<RectTransform>().sizeDelta;
    }
}
