﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FileDir {
    public static string ArmourIcon { get { return "Sprites/armouricon"; } }
	public static string BaseArmour {get {return "Prefabs/Items/BasicArmour"; }}
	public static string BaseSkillCore  {get {return "Prefabs/Items/SkillCore"; }}
	public static string BasicProjectile {get {return "Prefabs/Items/Projectiles/BasicArrow"; }}
    public static string Blank { get { return "Prefabs/Blank"; } }
    public static string BlankIcon { get { return "Sprites/nothing"; } }
	public static string BlueBG {get {return "Prefabs/UI/bluebg"; }}
    public static string ChainLightning { get { return "Prefabs/Skills/Lightning"; } }
	public static string EnemyHealthBar {get {return "Prefabs/Enemies/enemyhealthbar"; }}
	public static string EnemyIcon { get { return "Prefabs/UI/Minimap/enemyminimapicon"; } }
	public static string FadingText {get {return "Prefabs/UI/FadingText"; }}
    public static string FadingTextMid { get { return "Prefabs/UI/FadingTextMid"; } }
    public static string FireBall {get {return "Prefabs/Items/Projectiles/Fireball"; }}
    public static string GreaterHealingPotion { get { return "Prefabs/Items/GreaterHealingPotion"; } }
    public static string GroundOutline { get { return "Prefabs/UI/Minimap/GroundOutline"; } }
    public static string HealingItem {get {return "Prefabs/Items/HealingItem"; }}
    public static string HealingItemIcon { get { return "Sprites/healingitem"; } }
    public static string HealingPotion { get { return "Prefabs/Items/HealingPotion"; } }
    public static string HighGroundOutline { get { return "Prefabs/UI/Minimap/HighGroundOutline"; } }
    public static string KeyPress { get { return "Prefabs/KeyPress"; } }
    public static string LowGroundOutline { get { return "Prefabs/UI/Minimap/LowGroundOutline"; } }
    public static string InteractablePopup {get {return "Prefabs/Interactables/InteractablePopup"; }}
    public static string ItemMinimapIcon { get { return "Prefabs/UI/Minimap/itemminimapicon"; } }
	public static string ItemPickup {get {return "Prefabs/Items/itempickup"; }}
	public static string MerchantButton {get {return "Prefabs/Interactables/Merchant/MerchantButton"; }}
	public static string PlayerMinimapIcon {get {return "Prefabs/UI/Minimap/playerminimapicon"; }}
    public static string ProjectileIcon { get { return "Sprites/projectileicon"; } }
	public static string RandomArmourPickup {get {return "Prefabs/Items/RandomArmourPickup"; }}
	public static string RandomWeaponPickup {get {return "Prefabs/Items/RandomWeaponPickup"; }}
	public static string SkillButton {get {return "Prefabs/Skills/SkillButton"; }}
	public static string Sphere {get {return "Prefabs/Sphere"; }}
	public static string Text {get {return "Prefabs/text"; }}
	
}
